# -*- coding: utf-8 -*-
"""
hansen_downloader.py
====================
Téléchargement AUTOMATIQUE des tuiles *Hansen Global Forest Change* (GFC)
couvrant l'emprise des parcelles, pour la détection de déforestation EUDR.

Les données GFC sont publiées en tuiles de 10° × 10°, nommées d'après le coin
NORD-OUEST de la tuile, sur le stockage public Google Cloud d'Earth Engine
Partners. Ce module :

  * détermine la ou les tuiles couvrant une emprise (en WGS84) ;
  * construit les URL publiques (aucune clé API requise) ;
  * télécharge les GeoTIFF dans un cache local (réutilisé ensuite) ;
  * fusionne plusieurs tuiles en un VRT si l'emprise chevauche plusieurs
    granules.

Aucune dépendance externe : la pile réseau de QGIS
(`QgsBlockingNetworkRequest`, utilisable depuis une tâche d'arrière-plan et
respectant le proxy / SSL / l'authentification configurés dans QGIS) et
osgeo.gdal (livré avec QGIS) pour le VRT. Seul l'hôte public de diffusion des
données GFC est autorisé en HTTPS.

Structure des noms
------------------
Répertoire  : GFC-2023-v1.11
Fichier     : Hansen_GFC-2023-v1.11_<couche>_<lat>_<lon>.tif
  <lat> : 00N, 10N, 20N … ou 10S, 20S …  (coin supérieur de la tuile)
  <lon> : 000E, 010E … ou 010W, 020W …   (coin gauche de la tuile)
Couches utiles : lossyear (année de perte), treecover2000 (couvert initial),
                 loss, gain, datamask.
"""

import math
import os

from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtNetwork import QNetworkRequest
from qgis.core import QgsBlockingNetworkRequest

from . import plugin_log


def _compat_enum(cls, *paths):
    """Resout une valeur d'enumeration en essayant plusieurs chemins, pour
    rester compatible entre PyQt5 (enums "plats", ex: QNetworkRequest.
    UserAgentHeader) et PyQt6 (enums "scopes", ex: QNetworkRequest.
    KnownHeaders.UserAgentHeader)."""
    for path in paths:
        obj = cls
        try:
            for part in path.split("."):
                obj = getattr(obj, part)
            return obj
        except AttributeError:
            continue
    raise AttributeError("Aucun des chemins %s trouve sur %s" % (paths, cls))


NET_USER_AGENT_HEADER = _compat_enum(
    QNetworkRequest, "KnownHeaders.UserAgentHeader", "UserAgentHeader"
)
NET_HTTP_STATUS_ATTR = _compat_enum(
    QNetworkRequest, "Attribute.HttpStatusCodeAttribute", "HttpStatusCodeAttribute"
)
NET_NO_ERROR = _compat_enum(
    QgsBlockingNetworkRequest, "ErrorCode.NoError", "NoError"
)

HANSEN_BASE = "https://storage.googleapis.com/earthenginepartners-hansen"

# Seul hôte autorisé : on refuse toute autre destination (défense en profondeur).
ALLOWED_HOST = "storage.googleapis.com"
DEFAULT_VERSION = "GFC-2023-v1.11"

# Nombre maximal de tuiles téléchargées d'un coup (garde-fou : chaque tuile
# lossyear pèse plusieurs dizaines de Mo).
MAX_TILES = 12


def cache_dir():
    """Répertoire de cache local des tuiles (créé si nécessaire)."""
    d = os.path.join(os.path.expanduser("~"), "EUDR_Hansen_cache")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception as _exc:
        plugin_log.debug(__name__, _exc)
    return d


def granule_of(lon, lat):
    """Nom de granule (ex. « 10N_010W ») contenant le point (lon, lat) WGS84."""
    top = int(math.ceil(lat / 10.0) * 10)
    left = int(math.floor(lon / 10.0) * 10)
    lat_lab = ("%02dN" % top) if top >= 0 else ("%02dS" % abs(top))
    lon_lab = ("%03dE" % left) if left >= 0 else ("%03dW" % abs(left))
    return "%s_%s" % (lat_lab, lon_lab)


def tiles_for_extent(xmin, ymin, xmax, ymax):
    """Liste des granules couvrant l'emprise (coordonnées WGS84)."""
    # Bornes alignées sur la grille 10°.
    lon0 = int(math.floor(xmin / 10.0) * 10)
    lon1 = int(math.floor(xmax / 10.0) * 10)
    lat0 = int(math.floor(ymin / 10.0) * 10)
    lat1 = int(math.floor(ymax / 10.0) * 10)
    tiles = []
    lat = lat0
    while lat <= lat1:
        lon = lon0
        while lon <= lon1:
            # point représentatif au centre de la cellule de grille
            tiles.append(granule_of(lon + 5.0, lat + 5.0))
            lon += 10
        lat += 10
    # dédoublonnage en conservant l'ordre
    seen = set()
    out = []
    for t in tiles:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out


def tile_url(granule, layer, version=DEFAULT_VERSION):
    """URL publique d'une tuile GFC."""
    fname = "Hansen_%s_%s_%s.tif" % (version, layer, granule)
    return "%s/%s/%s" % (HANSEN_BASE, version, fname)


def local_path(granule, layer, version=DEFAULT_VERSION):
    """Chemin local (cache) d'une tuile."""
    fname = "Hansen_%s_%s_%s.tif" % (version, layer, granule)
    return os.path.join(cache_dir(), fname)


def _is_allowed(url):
    """N'autorise que HTTPS vers l'hôte public de diffusion des données GFC."""
    u = QUrl(url)
    return u.scheme() == "https" and u.host() == ALLOWED_HOST


def download_file(url, dest, progress_cb=None, cancel_cb=None):
    """
    Télécharge `url` vers `dest` via la pile réseau de QGIS
    (`QgsBlockingNetworkRequest`) : utilisable depuis une tâche d'arrière-plan,
    et respecte le proxy, le SSL et l'authentification configurés dans QGIS.

    Retourne (True, None) en cas de succès, (False, message) sinon.
    Une tuile inexistante (océan) renvoie (False, "404").
    """
    if not _is_allowed(url):
        return False, "URL refusée (schéma ou hôte non autorisé)"
    if cancel_cb and cancel_cb():
        return False, "annulé"

    request = QNetworkRequest(QUrl(url))
    request.setHeader(NET_USER_AGENT_HEADER, "QGIS-EUDR-Plugin")

    fetcher = QgsBlockingNetworkRequest()
    if progress_cb:
        def _on_progress(received, total):
            if total:
                progress_cb(min(100.0, received / float(total) * 100.0))
        fetcher.downloadProgress.connect(_on_progress)

    err = fetcher.get(request)
    reply = fetcher.reply()

    status = None
    if reply is not None:
        status = reply.attribute(NET_HTTP_STATUS_ATTR)
    if status == 404:
        return False, "404"          # tuile absente (hors terres émergées)
    if err != NET_NO_ERROR:
        return False, fetcher.errorMessage() or "erreur réseau"
    if status is not None and status != 200:
        return False, "HTTP %s" % status
    if reply is None:
        return False, "réponse vide"

    tmp = dest + ".part"
    try:
        with open(tmp, "wb") as f:
            f.write(bytes(reply.content()))
        os.replace(tmp, dest)
    except OSError as exc:
        if os.path.exists(tmp):
            os.remove(tmp)
        return False, str(exc)
    return True, None


def ensure_layer(granules, layer, version=DEFAULT_VERSION,
                 progress_cb=None, log_cb=None, cancel_cb=None):
    """
    Garantit la présence locale d'une couche GFC pour l'ensemble des granules.
    Télécharge ce qui manque, puis renvoie un chemin unique exploitable :
      * le .tif si une seule tuile ;
      * un .vrt fusionnant les tuiles si plusieurs.
    Retourne (chemin ou None, liste des granules réellement disponibles).
    """
    available = []
    n = len(granules)
    for i, g in enumerate(granules):
        if cancel_cb and cancel_cb():
            return None, available
        dest = local_path(g, layer, version)
        if os.path.exists(dest) and os.path.getsize(dest) > 0:
            if log_cb:
                log_cb("  ↺ %s %s déjà en cache." % (layer, g))
            available.append(dest)
        else:
            url = tile_url(g, layer, version)
            if log_cb:
                log_cb("  ⬇ Téléchargement %s %s…" % (layer, g))

            def _p(pct, base=i, count=n):
                if progress_cb:
                    progress_cb((base + pct / 100.0) / count * 100.0)

            ok, err = download_file(url, dest, progress_cb=_p,
                                    cancel_cb=cancel_cb)
            if ok:
                available.append(dest)
            elif err == "404":
                if log_cb:
                    log_cb("  ⚠ Tuile %s absente (probablement hors terres)."
                           % g)
            else:
                if log_cb:
                    log_cb("  ✗ Échec %s %s : %s" % (layer, g, err))
        if progress_cb:
            progress_cb((i + 1) / n * 100.0)

    if not available:
        return None, available
    if len(available) == 1:
        return available[0], available
    # Fusion multi-tuiles en VRT.
    vrt_path = os.path.join(
        cache_dir(), "merged_%s_%s.vrt" % (layer, "_".join(granules)))
    try:
        from osgeo import gdal
        gdal.BuildVRT(vrt_path, available)
        if log_cb:
            log_cb("  ⛓ %d tuiles fusionnées (VRT)." % len(available))
        return vrt_path, available
    except Exception as exc:
        if log_cb:
            log_cb("  ⚠ Fusion VRT impossible (%s) ; 1re tuile utilisée." % exc)
        return available[0], available
