# Deforestation Risk Analyzer (QGIS Plugin)

Plugin QGIS pour l'analyse de risque de déforestation par polygone
(parcelles MyRA / cacao), avec vérification EUDR.

## Installation (test local)

1. Décompresser le ZIP. Le dossier doit s'appeler `deforestation_risk_plugin`
   et contenir directement `metadata.txt`, `__init__.py`, etc. (pas de
   sous-dossier supplémentaire).
2. Copier ce dossier dans le répertoire des plugins QGIS :
   - Windows : `C:\Users\<utilisateur>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
   - Linux/Mac : `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
3. Ouvrir QGIS -> Extensions -> Gérer et installer les extensions ->
   onglet "Installées" -> cocher "Deforestation Risk Analyzer".
4. Une icône apparaît dans la barre d'outils (et dans le menu Extensions).

## Utilisation

### 1. Couche à analyser

Veuillez ajouter ici la couche à analyser (ex. export MyRA), dans le menu
déroulant, et optionnellement le champ identifiant (utilisé ensuite pour
lister les codes de parcelles à risque dans le rapport).

### 2. Ajouter des couches de référence / vérification

Trois boutons, chacun ouvrant une petite liste à cocher (tu peux cocher
plusieurs options à la fois) :

- **"Ajouter couche..."** : coche **Raster (.tif)** et/ou **Vecteur
  (Shapefile .shp)** pour ajouter tes propres fichiers locaux
  (classification Landsat, alertes RADD/GLAD exportées en raster, carte
  SOC, forêts classées, etc.).
- **"Télécharger raster..."** : coche **ESA WorldCover** (occupation du
  sol 2020, résolution 10m, référence EUDR, lecture distante sans
  téléchargement complet ni clé API) et/ou **Hansen GFC** (téléchargement
  automatique des tuiles Global Forest Change -- bande `lossyear` : 0 =
  pas de perte, 1-23 = perte en 2001-2023 -- couvrant l'emprise des
  parcelles, avec mise en cache locale et fusion en VRT si plusieurs
  tuiles, plus le raster `treecover2000` en option).
- **"Utiliser couche déjà chargée..."** : coche **Raster** et/ou
  **Vecteur** pour réutiliser une couche déjà ouverte dans QGIS, sans
  repasser par l'explorateur de fichiers.

Pour un raster ajouté ou téléchargé (classification, Hansen, WorldCover),
une fenêtre s'ouvre avec un tableau des valeurs de pixel détectées
automatiquement (jusqu'à une centaine de classes). Pour chaque valeur :
- donne un **nom de classe** (ex. "Forêt primaire", "Jachère") ;
- choisis son **niveau de risque** parmi 5 (Très faible, Faible, Moyen,
  Élevé, Très élevé), ou laisse "Aucun risque" (ex. Eau, Cacao mature) ;
- ajoute un **commentaire (cause)** optionnel, ex. "Espace anciennement
  jachère", qui alimentera la colonne de commentaire propre à cette
  couche dans le résultat final.

**Important** : dès qu'un raster est classé (fenêtre validée, case "Ne
pas classer" décochée), son résultat est **toujours** déterminé par les
classes assignées -- jamais par un pourcentage comparé au seuil. Une
classe laissée sur "Aucun risque" donne ce résultat exact ("Aucun
risque"), un niveau réel et distinct de "Très faible" (et non un simple
repli silencieux sur "Très faible"). Le seuil (%) de la section 3 ne
s'applique qu'aux couches **non classées** (vecteur avec classes
cochées, ou raster en mode "valeurs brutes").

Avec beaucoup de classes (ex. 40), tu peux **copier une colonne depuis
Excel et la coller** (Ctrl+V, clic droit > Coller, ou le bouton dédié)
directement dans le tableau. Si le raster est déjà un masque binaire
(0/1), coche "Ne pas classer".

Pour un shapefile, choisis la colonne qui contient les classes puis
coche, parmi les valeurs réellement présentes, celles à considérer comme
"à risque" ("Tout cocher"/"Tout décocher" disponibles). Un commentaire de
cause peut aussi être associé à l'ensemble des classes cochées.

- **Cache de configuration** : les noms de classe, niveaux et
  commentaires déjà saisis pour une couche donnée sont **mémorisés** et
  reproposés par défaut si tu réutilises cette même couche plus tard
  (ajout, réutilisation, ou "Configurer les classes...").

### 3. Cocher/décocher les couches à analyser

Chaque couche ajoutée apparaît avec une case à cocher dans la liste.
Seules les couches cochées sont prises en compte au moment de "Lancer
l'analyse" -- utile pour tester rapidement différentes combinaisons sans
tout ré-importer.

### 4. Seuil de risque

Le seuil (%) définit la limite "Élevé" ; les autres limites de l'échelle
à 5 niveaux en sont déduites proportionnellement (seuil/2 = "Moyen",
2 x seuil = "Très élevé").

### 5. Lancer l'analyse

Le plugin :

- copie la couche de parcelles en mémoire (le fichier source n'est
  jamais modifié) ;
- pour chaque **raster classé** (niveaux de risque définis) : détermine,
  pour chaque polygone, le **niveau le plus élevé** parmi les classes
  présentes (jamais une moyenne diluée -- une parcelle touchant ne
  serait-ce qu'un peu une classe "Très élevé" est classée "Très élevé") ;
- pour chaque **shapefile** : calcule le % de surface du polygone
  recouvert par les classes cochées ;
- construit une **colonne de commentaire par couche de référence
  cochée** (ex. `hansengf_comment`, `basefc_comment`...), qui concatène
  les causes détectées pour cette couche précise (classes présentes dans
  chaque parcelle) -- une colonne de plus par couche ayant au moins un
  commentaire renseigné ;
- construit les champs de synthèse **`risque_score`** (Très faible /
  Faible / Moyen / Élevé / Très élevé -- le niveau le plus élevé parmi
  **toutes** les couches de référence cochées pour l'analyse, jamais une
  moyenne) et **`risque_max_pct`**.

Le raster est **découpé à l'emprise des parcelles** avant tout calcul
lourd (bien plus rapide qu'un traitement sur un raster national entier).
Un bouton **"Annuler"** permet d'interrompre une analyse en cours (l'arrêt
peut prendre quelques secondes le temps qu'un traitement en cours détecte
la demande).

### 6. Générer un rapport (Excel)

Un bouton dédié ouvre une fenêtre pour renseigner un logo, une image de
signature et un nom/titre de signataire, puis génère un classeur Excel
(.xlsx) sur 3 feuilles, avec mise en forme colorée :

- **"Résumé"** : logo, date et heure de l'analyse, nombre de parcelles,
  seuil utilisé, tableau de répartition du risque coloré par niveau
  (vert → rouge), méthodologie (couches de référence utilisées), et
  signature en bas de page ;
- **"Parcelles à risque"** : tableau des codes de parcelles classées
  Moyen, Élevé ou Très élevé, triées par gravité, avec la cellule de
  niveau colorée ;
- **"Résultat complet"** : la table attributaire complète, avec la
  colonne `risque_score` colorée par niveau et des bandes de lignes
  alternées pour la lisibilité.

## Notes techniques importantes avant de tester

- Le système de coordonnées (CRS) des couches de référence doit
  correspondre (ou être reprojetable automatiquement par QGIS) à celui
  de la couche de parcelles ; le plugin reprojette automatiquement les
  emprises et géométries si nécessaire.
- Les couches **WMS** (flux réseau) sont nettement plus lentes qu'un
  fichier local (chaque parcelle déclenche des requêtes internet) et ne
  peuvent pas être accélérées par découpe locale. Pour de gros volumes,
  mieux vaut télécharger la couche en GeoTIFF et l'ajouter via "Ajouter
  raster (.tif)".
- Pour de très gros volumes de parcelles, le calcul vecteur-vecteur
  (recouvrement avec un shapefile de référence) reste fait en pur Python
  et peut prendre du temps sur une couche de référence très détaillée.

## Structure des fichiers

```
deforestation_risk_plugin/
    __init__.py                   -> point d'entrée QGIS (classFactory)
    metadata.txt                   -> nom, version, description du plugin
    deforestation_risk_plugin.py   -> classe principale (menu / toolbar)
    risk_dialog.py                  -> interface graphique (PyQt5/PyQt6)
    risk_engine.py                  -> logique de calcul (raster/vecteur/score/rapport)
    icon.png                        -> icône de la barre d'outils
    README.md                       -> ce fichier
```
