# -*- coding: utf-8 -*-
"""
extra_sources.py
================
Sources de reference supplementaires, portees depuis un autre plugin
(Deforestation check by J.D. Konan) a la demande de l'utilisateur, qui a
constate qu'elles fonctionnent de maniere fiable :

- ESA WorldCover : ajout direct en lecture distante (Cloud Optimized
  GeoTIFF via /vsicurl/), sans telechargement complet ni cle API.
  Occupation du sol 10m, annee de reference 2020 (utilisee par l'EUDR)
  ou 2021.
"""

import math
import os

from qgis.core import QgsRasterLayer
from . import plugin_log

WORLDCOVER_BASE = "https://esa-worldcover.s3.eu-central-1.amazonaws.com"
# annee -> (version, annee texte)
WORLDCOVER = {2021: ("v200", "2021"), 2020: ("v100", "2020")}


def _wc_label(lat, lon):
    la = ("N%02d" % lat) if lat >= 0 else ("S%02d" % abs(lat))
    lo = ("E%03d" % lon) if lon >= 0 else ("W%03d" % abs(lon))
    return la + lo


def worldcover_tiles(xmin, ymin, xmax, ymax):
    """Granules 3 deg x 3 deg (coin sud-ouest) couvrant l'emprise WGS84."""
    lon0 = int(math.floor(xmin / 3.0) * 3)
    lon1 = int(math.floor(xmax / 3.0) * 3)
    lat0 = int(math.floor(ymin / 3.0) * 3)
    lat1 = int(math.floor(ymax / 3.0) * 3)
    tiles = []
    lat = lat0
    while lat <= lat1:
        lon = lon0
        while lon <= lon1:
            tiles.append(_wc_label(lat, lon))
            lon += 3
        lat += 3
    return tiles


def worldcover_url(tile, year=2020):
    ver, yr = WORLDCOVER.get(year, WORLDCOVER[2020])
    return ("%s/%s/%s/map/ESA_WorldCover_10m_%s_%s_%s_Map.tif"
            % (WORLDCOVER_BASE, ver, yr, yr, ver, tile))


def add_worldcover(xmin, ymin, xmax, ymax, year=2020, log_cb=None):
    """Ajoute ESA WorldCover en lecture distante (/vsicurl/), sur
    l'emprise donnee (WGS84). Retourne un QgsRasterLayer (VRT si plusieurs
    tuiles necessaires) ou None en cas d'echec."""
    tiles = worldcover_tiles(xmin, ymin, xmax, ymax)
    if not tiles:
        return None
    vsipaths = ["/vsicurl/" + worldcover_url(t, year) for t in tiles]
    if log_cb:
        log_cb("WorldCover %d : %d tuile(s) -- %s"
               % (year, len(tiles), ", ".join(tiles)))
    if len(vsipaths) == 1:
        path = vsipaths[0]
    else:
        try:
            from osgeo import gdal
            import tempfile
            vrt = os.path.join(
                tempfile.gettempdir(),
                "worldcover_%d_%s.vrt" % (year, "_".join(tiles)))
            gdal.BuildVRT(vrt, vsipaths)
            path = vrt
        except Exception as exc:
            plugin_log.debug(__name__, exc)
            path = vsipaths[0]
    layer = QgsRasterLayer(path, "ESA WorldCover %d" % year, "gdal")
    return layer if layer.isValid() else None
