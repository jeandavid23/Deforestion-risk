# -*- coding: utf-8 -*-
"""
risk_dialog.py
Interface graphique du plugin. Permet :
- de choisir la couche de parcelles (polygones)
- d'ajouter la couche officielle JRC GFC2020 (WMS) en un clic
- d'ajouter un nombre illimite de couches de reference TIF (raster) ou SHP
  (vecteur), avec possibilite de designer une colonne de classes et de
  cocher les classes a considerer comme "a risque"
- de cocher/decocher chaque couche pour l'inclure ou non dans l'analyse
- de lancer le calcul de risque et d'exporter le resultat
"""

import os
import traceback
from datetime import date, datetime

from qgis.core import QgsMapLayerProxyModel, QgsProject, QgsRasterLayer, QgsVectorLayer, QgsProcessingFeedback
from qgis.gui import QgsMapLayerComboBox, QgsFieldComboBox
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QKeySequence
from qgis.PyQt.QtWidgets import (
    QApplication,
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QListWidget,
    QListWidgetItem,
    QFileDialog,
    QDoubleSpinBox,
    QProgressBar,
    QMessageBox,
    QGroupBox,
    QCheckBox,
    QLineEdit,
    QDialogButtonBox,
    QTableWidget,
    QTableWidgetItem,
    QComboBox,
    QMenu,
)

from . import risk_engine
from . import hansen_downloader as hd
from . import raster_style
from . import extra_sources


def _exec_dialog(dlg):
    """Ouvre une boite de dialogue modale, compatible PyQt5 (exec_) et
    PyQt6 (exec), selon la version de Qt utilisee par QGIS."""
    if hasattr(dlg, "exec"):
        return dlg.exec()
    return dlg.exec_()


def _compat_enum(cls, *paths):
    """Resout une valeur d'enumeration en essayant plusieurs chemins,
    pour rester compatible entre PyQt5 (enums 'plats', ex: CHECK_CHECKED) et
    PyQt6 (enums 'scopes', ex: Qt.CheckState.Checked)."""
    for path in paths:
        obj = cls
        try:
            for part in path.split("."):
                obj = getattr(obj, part)
            return obj
        except AttributeError:
            continue
    raise AttributeError(f"Aucun des chemins {paths} trouve sur {cls}")


# Constantes resolues une seule fois au chargement du module, valables que
# QGIS tourne sous PyQt5 (Qt5) ou PyQt6 (Qt6).
DIALOG_ACCEPTED = _compat_enum(QDialog, "DialogCode.Accepted", "Accepted")
BTN_OK = _compat_enum(QDialogButtonBox, "StandardButton.Ok", "Ok")
BTN_CANCEL = _compat_enum(QDialogButtonBox, "StandardButton.Cancel", "Cancel")
ITEM_USER_CHECKABLE = _compat_enum(Qt, "ItemFlag.ItemIsUserCheckable", "ItemIsUserCheckable")
CHECK_CHECKED = _compat_enum(Qt, "CheckState.Checked", "Checked")
CHECK_UNCHECKED = _compat_enum(Qt, "CheckState.Unchecked", "Unchecked")
DATA_USER_ROLE = _compat_enum(Qt, "ItemDataRole.UserRole", "UserRole")
ITEM_EDITABLE = _compat_enum(Qt, "ItemFlag.ItemIsEditable", "ItemIsEditable")
PASTE_SEQUENCE = _compat_enum(QKeySequence, "StandardKey.Paste", "Paste")
CONTEXT_MENU_CUSTOM = _compat_enum(
    Qt, "ContextMenuPolicy.CustomContextMenu", "CustomContextMenu"
)
DONT_USE_NATIVE_DIALOG = _compat_enum(
    QFileDialog, "Option.DontUseNativeDialog", "DontUseNativeDialog"
)


# ----------------------------------------------------------------------
# Fenetre de selection de classes pour une couche VECTEUR (shapefile)
# ----------------------------------------------------------------------
class VectorClassDialog(QDialog):
    def __init__(self, layer, parent=None, initial_config=None):
        super().__init__(parent)
        self.layer = layer
        # initial_config : tuple (class_field, risk_values_set, comment) ou
        # None -- utilise pour pre-remplir la selection si cette couche a
        # deja ete configuree precedemment.
        self._initial_field, self._initial_values, self._initial_comment = (
            initial_config if initial_config else (None, None, None)
        )
        self._initial_values = set(self._initial_values or [])
        self.setWindowTitle(f"Classes a risque - {layer.name()}")
        self.resize(380, 420)

        layout = QVBoxLayout()

        self.no_class_check = QCheckBox(
            "Ne pas classer : utiliser toute la couche telle quelle"
        )
        layout.addWidget(self.no_class_check)

        layout.addWidget(QLabel("Colonne qui contient les classes (ex: 'classe', 'type_couv') :"))
        self.field_combo = QgsFieldComboBox()
        self.field_combo.setLayer(layer)
        layout.addWidget(self.field_combo)

        layout.addWidget(QLabel("Cocher les classes a considerer comme 'a risque' :"))

        check_btn_row = QHBoxLayout()
        self.btn_check_all = QPushButton("Tout cocher")
        self.btn_uncheck_all = QPushButton("Tout decocher")
        check_btn_row.addWidget(self.btn_check_all)
        check_btn_row.addWidget(self.btn_uncheck_all)
        layout.addLayout(check_btn_row)

        self.value_list = QListWidget()
        layout.addWidget(self.value_list)

        layout.addWidget(QLabel(
            "Commentaire (cause) applique aux parcelles touchees par les "
            "classes cochees ci-dessus, ex: 'Parcelle en Foret classee' :"
        ))
        self.comment_edit = QLineEdit()
        self.comment_edit.setPlaceholderText("ex: Parcelle en Foret classee")
        if self._initial_comment:
            self.comment_edit.setText(self._initial_comment)
        layout.addWidget(self.comment_edit)

        self.btn_check_all.clicked.connect(lambda: self._set_all_checked(True))
        self.btn_uncheck_all.clicked.connect(lambda: self._set_all_checked(False))
        self.field_combo.fieldChanged.connect(self._reload_values)
        self.no_class_check.toggled.connect(self._toggle_no_class)

        buttons = QDialogButtonBox(BTN_OK | BTN_CANCEL)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.setLayout(layout)

        # Si une colonne de classes a deja ete utilisee pour cette couche,
        # la re-selectionner par defaut (declenche _reload_values via le
        # signal fieldChanged) ; sinon on charge la colonne courante.
        if self._initial_field:
            self.field_combo.setField(self._initial_field)
        else:
            self._reload_values(self.field_combo.currentField())

    def _set_all_checked(self, checked):
        state = CHECK_CHECKED if checked else CHECK_UNCHECKED
        for i in range(self.value_list.count()):
            self.value_list.item(i).setCheckState(state)

    def _toggle_no_class(self, checked):
        self.field_combo.setEnabled(not checked)
        self.value_list.setEnabled(not checked)
        self.btn_check_all.setEnabled(not checked)
        self.btn_uncheck_all.setEnabled(not checked)
        self.comment_edit.setEnabled(not checked)

    def _reload_values(self, field_name):
        self.value_list.clear()
        if not field_name:
            return
        values = risk_engine.get_unique_field_values(self.layer, field_name)
        # Les valeurs cochees precedemment ne sont reappliquees que si la
        # colonne selectionnee est bien celle utilisee lors de la
        # configuration precedente (sinon les classes ne correspondent pas).
        preselect = self._initial_values if field_name == self._initial_field else set()
        for v in values:
            item = QListWidgetItem(v)
            item.setFlags(item.flags() | ITEM_USER_CHECKABLE)
            item.setCheckState(CHECK_CHECKED if v in preselect else CHECK_UNCHECKED)
            self.value_list.addItem(item)

    def get_result(self):
        """Retourne (class_field, risk_values, comment) ou (None, None, None)
        si l'utilisateur a choisi de ne pas classer la couche."""
        if self.no_class_check.isChecked():
            return None, None, None
        field_name = self.field_combo.currentField()
        selected = []
        for i in range(self.value_list.count()):
            item = self.value_list.item(i)
            if item.checkState() == CHECK_CHECKED:
                selected.append(item.text())
        comment = self.comment_edit.text().strip()
        if not field_name or not selected:
            return None, None, None
        return field_name, selected, (comment or None)


# ----------------------------------------------------------------------
# Tableau supportant le collage (Ctrl+V) de donnees copiees depuis Excel
# ----------------------------------------------------------------------
class PasteableTableWidget(QTableWidget):
    """QTableWidget classique, mais qui accepte le collage (Ctrl+V) de
    donnees copiees depuis Excel (texte separe par tabulations/retours a
    la ligne). Colle a partir de la cellule selectionnee : colonne 'Nom de
    la classe' -> texte direct ; colonne 'Niveau de risque' -> tente de
    faire correspondre le texte colle a l'un des 5 niveaux (insensible a
    la casse/aux espaces). Un clic droit (sans avoir besoin de double-clic
    prealable) ouvre aussi un menu avec l'option 'Coller'."""

    def __init__(self, rows=0, columns=0, parent=None):
        super().__init__(rows, columns, parent)
        self.setContextMenuPolicy(CONTEXT_MENU_CUSTOM)
        self.customContextMenuRequested.connect(self._show_context_menu)

    def _show_context_menu(self, pos):
        # Un clic droit doit d'abord positionner la selection sur la
        # cellule visee (sinon le clic droit ne fait que montrer le menu
        # sans indiquer ou coller), avant d'ouvrir le menu.
        row = self.rowAt(pos.y())
        col = self.columnAt(pos.x())
        if row >= 0 and col >= 0:
            self.setCurrentCell(row, col)

        menu = QMenu(self)
        paste_action = menu.addAction("Coller")
        paste_action.triggered.connect(self.paste_from_clipboard)

        global_pos = self.viewport().mapToGlobal(pos)
        if hasattr(menu, "exec"):
            menu.exec(global_pos)
        else:
            menu.exec_(global_pos)

    def keyPressEvent(self, event):
        if event.matches(PASTE_SEQUENCE):
            self.paste_from_clipboard()
            return
        super().keyPressEvent(event)

    def paste_from_clipboard(self):
        text = QApplication.clipboard().text()
        if not text:
            return
        rows = [
            r for r in text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
            if r != ""
        ]
        if not rows:
            return

        start_row = self.currentRow() if self.currentRow() >= 0 else 0
        start_col = self.currentColumn() if self.currentColumn() >= 0 else 1

        for i, row_text in enumerate(rows):
            target_row = start_row + i
            if target_row >= self.rowCount():
                break
            for j, value in enumerate(row_text.split("\t")):
                target_col = start_col + j
                if target_col >= self.columnCount():
                    break
                value = value.strip()
                self._paste_into_cell(target_row, target_col, value)

    def _paste_into_cell(self, row, col, value):
        if col == 1:  # Nom de la classe
            item = self.item(row, 1)
            if item is None:
                item = QTableWidgetItem()
                self.setItem(row, 1, item)
            item.setText(value)
        elif col == 2:  # Niveau de risque (menu deroulant)
            combo = self.cellWidget(row, 2)
            if combo is None:
                return
            normalized = value.strip().lower()
            for k in range(combo.count()):
                if combo.itemText(k).strip().lower() == normalized:
                    combo.setCurrentIndex(k)
                    return
        elif col == 3:  # Commentaire (cause) -- texte libre
            item = self.item(row, 3)
            if item is None:
                item = QTableWidgetItem()
                self.setItem(row, 3, item)
            item.setText(value)
        elif col == 0:  # Valeur (normalement en lecture seule)
            item = self.item(row, 0)
            if item is not None and (item.flags() & ITEM_EDITABLE):
                item.setText(value)


# ----------------------------------------------------------------------
# Fenetre generique : liste a cocher lancant une ou plusieurs actions
# ----------------------------------------------------------------------
class MultiChoiceLauncherDialog(QDialog):
    """Affiche une liste a cocher (ex: 'Raster' / 'Vecteur') pour un bouton
    regroupant plusieurs actions. get_selected_keys() renvoie les cles des
    options cochees, dans l'ordre de la liste ; l'appelant execute ensuite
    l'action correspondante pour chaque cle cochee."""

    def __init__(self, title, hint_text, choices, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(420, 220)

        layout = QVBoxLayout()
        if hint_text:
            hint = QLabel(hint_text)
            hint.setWordWrap(True)
            layout.addWidget(hint)

        self.list_widget = QListWidget()
        for key, label in choices:
            item = QListWidgetItem(label)
            item.setFlags(item.flags() | ITEM_USER_CHECKABLE)
            item.setCheckState(CHECK_UNCHECKED)
            item.setData(DATA_USER_ROLE, key)
            self.list_widget.addItem(item)
        layout.addWidget(self.list_widget)

        buttons = QDialogButtonBox(BTN_OK | BTN_CANCEL)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.setLayout(layout)

    def get_selected_keys(self):
        keys = []
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.checkState() == CHECK_CHECKED:
                keys.append(item.data(DATA_USER_ROLE))
        return keys


# ----------------------------------------------------------------------
# Fenetre de selection d'une couche deja chargee dans le projet QGIS
# ----------------------------------------------------------------------
class ExistingLayerPickerDialog(QDialog):
    def __init__(self, layer_filter, title, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(420, 120)

        layout = QVBoxLayout()
        layout.addWidget(QLabel("Selectionner une couche parmi celles deja ouvertes dans QGIS :"))

        self.combo = QgsMapLayerComboBox()
        self.combo.setFilters(layer_filter)
        layout.addWidget(self.combo)

        buttons = QDialogButtonBox(BTN_OK | BTN_CANCEL)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.setLayout(layout)

    def get_result(self):
        return self.combo.currentLayer()


# ----------------------------------------------------------------------
# Fenetre de configuration du rapport PDF (logo, signature)
# ----------------------------------------------------------------------
class ReportConfigDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configurer le rapport Excel")
        self.resize(460, 260)

        layout = QVBoxLayout()

        layout.addWidget(QLabel(
            "Nom / titre du signataire (ex: ton nom et ta fonction), affiche "
            "au-dessus de la signature :"
        ))
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("ex: Yao Kouadio Arnaud, Doctorant UJLoG")
        layout.addWidget(self.name_edit)

        layout.addWidget(QLabel("Logo (image, optionnel, affiche en haut du rapport) :"))
        logo_row = QHBoxLayout()
        self.logo_path_edit = QLineEdit()
        self.logo_path_edit.setReadOnly(True)
        btn_logo = QPushButton("Choisir...")
        btn_logo.clicked.connect(self._pick_logo)
        logo_row.addWidget(self.logo_path_edit)
        logo_row.addWidget(btn_logo)
        layout.addLayout(logo_row)

        layout.addWidget(QLabel(
            "Image de signature (optionnel, affichee en bas du rapport) :"
        ))
        sig_row = QHBoxLayout()
        self.signature_path_edit = QLineEdit()
        self.signature_path_edit.setReadOnly(True)
        btn_sig = QPushButton("Choisir...")
        btn_sig.clicked.connect(self._pick_signature)
        sig_row.addWidget(self.signature_path_edit)
        sig_row.addWidget(btn_sig)
        layout.addLayout(sig_row)

        buttons = QDialogButtonBox(BTN_OK | BTN_CANCEL)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.setLayout(layout)

    def _pick_logo(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Choisir un logo", "", "Images (*.png *.jpg *.jpeg)",
            "", DONT_USE_NATIVE_DIALOG,
        )
        if path:
            self.logo_path_edit.setText(path)

    def _pick_signature(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Choisir une image de signature", "", "Images (*.png *.jpg *.jpeg)",
            "", DONT_USE_NATIVE_DIALOG,
        )
        if path:
            self.signature_path_edit.setText(path)

    def get_result(self):
        return (
            self.name_edit.text().strip() or None,
            self.logo_path_edit.text().strip() or None,
            self.signature_path_edit.text().strip() or None,
        )


# ----------------------------------------------------------------------
# Fenetre de selection de classes pour une couche RASTER (.tif)
# ----------------------------------------------------------------------
class RasterClassDialog(QDialog):
    """Detecte automatiquement les valeurs de pixel presentes dans le
    raster (ex: codes 1, 2, 3 d'une classification Landsat) et permet de
    leur donner un nom (ex: 'Foret primaire', 'Jachere') et un NIVEAU DE
    RISQUE parmi 5 (Très faible -> Très élevé). Le niveau choisi sert a la
    fois au calcul (poids 0-100 par classe) et a la couleur affichee sur la
    carte (rouge = Très élevé, vert = Très faible)."""

    def __init__(self, layer, parent=None, initial_config=None):
        super().__init__(parent)
        self.layer = layer
        # initial_config : dict {valeur_pixel: {"label":.., "level":.., "comment":..}}
        # utilise pour pre-remplir la classification si cette couche a deja
        # ete configuree precedemment (ex: via un autre bouton d'ajout).
        self.initial_config = initial_config or {}
        self.setWindowTitle(f"Niveau de risque par classe - {layer.name()}")
        self.resize(720, 460)

        layout = QVBoxLayout()

        self.no_class_check = QCheckBox(
            "Ne pas classer : utiliser les valeurs brutes du raster (ex: masque deja 0/1)"
        )
        layout.addWidget(self.no_class_check)

        self.info_label = QLabel("Detection des valeurs presentes dans le raster...")
        self.info_label.setWordWrap(True)
        layout.addWidget(self.info_label)

        self.paste_hint = QLabel(
            "Astuce : avec beaucoup de classes (ex: 40), copie la colonne des "
            "noms depuis Excel, clique sur la 1ere cellule de 'Nom de la "
            "classe' ci-dessous, puis Ctrl+V (ou le bouton 'Coller') pour "
            "tout remplir d'un coup, dans l'ordre des valeurs detectees."
        )
        self.paste_hint.setWordWrap(True)
        layout.addWidget(self.paste_hint)

        paste_btn_row = QHBoxLayout()
        self.btn_paste = QPushButton("Coller depuis le presse-papiers")
        paste_btn_row.addWidget(self.btn_paste)
        paste_btn_row.addStretch()
        layout.addLayout(paste_btn_row)

        self.table = PasteableTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(
            ["Valeur (code pixel)", "Nom de la classe", "Niveau de risque", "Commentaire (cause)"]
        )
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setColumnWidth(0, 110)
        self.table.setColumnWidth(1, 180)
        self.table.setColumnWidth(2, 140)
        layout.addWidget(self.table)

        self.btn_paste.clicked.connect(self._paste_button_clicked)

        self.no_class_check.toggled.connect(
            lambda checked: self.table.setEnabled(not checked)
        )

        buttons = QDialogButtonBox(BTN_OK | BTN_CANCEL)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.setLayout(layout)
        self._populate_values()

    def _paste_button_clicked(self):
        # Si aucune cellule n'a encore ete cliquee, on selectionne par
        # defaut la 1ere ligne de la colonne "Nom de la classe", pour que
        # le collage remplisse bien les noms depuis le debut.
        if self.table.currentRow() < 0 and self.table.rowCount() > 0:
            self.table.setCurrentCell(0, 1)
        self.table.paste_from_clipboard()

    def _populate_values(self):
        values = risk_engine.get_raster_unique_values(self.layer)
        self.table.setRowCount(0)

        if not values:
            self.info_label.setText(
                "Aucune classe detectee automatiquement (raster continu, ou trop "
                "de valeurs distinctes). Coche 'Ne pas classer', ou saisis "
                "manuellement une ligne par valeur avec le bouton ci-dessous."
            )
            add_row_btn = QPushButton("Ajouter une ligne (valeur manuelle)")
            add_row_btn.clicked.connect(lambda: self._add_row())
            self.layout().insertWidget(self.layout().count() - 1, add_row_btn)
            return

        self.info_label.setText(
            f"{len(values)} valeur(s) detectee(s). Donne un nom a chaque classe "
            "et choisis son niveau de risque (laisse 'Aucun risque' pour l'exclure "
            "du calcul, ex: Eau, Cacao mature)."
        )
        for v in values:
            self._add_row(v)

    def _add_row(self, value=None):
        row = self.table.rowCount()
        self.table.insertRow(row)

        value_item = QTableWidgetItem("" if value is None else str(value))
        if value is None:
            value_item.setFlags(value_item.flags() | ITEM_EDITABLE)
        else:
            value_item.setFlags(value_item.flags() & ~ITEM_EDITABLE)
        self.table.setItem(row, 0, value_item)

        cached = self.initial_config.get(value, {}) if value is not None else {}

        name_item = QTableWidgetItem(cached.get("label", ""))
        self.table.setItem(row, 1, name_item)

        level_combo = QComboBox()
        level_combo.addItem("Aucun risque")
        level_combo.addItems(risk_engine.RISK_LEVELS)
        cached_level = cached.get("level")
        if cached_level:
            for k in range(level_combo.count()):
                if level_combo.itemText(k) == cached_level:
                    level_combo.setCurrentIndex(k)
                    break
        self.table.setCellWidget(row, 2, level_combo)

        comment_item = QTableWidgetItem(cached.get("comment", ""))
        self.table.setItem(row, 3, comment_item)

    def get_result(self):
        """Retourne (value_risk_map, value_labels, value_comments, classified) :
        - classified : True si l'utilisateur a classe ce raster (case
          "Ne pas classer" DEcochee), meme si aucune classe n'a recu de
          niveau de risque -- ce cas doit systematiquement etre traite
          par classe (poids "Aucun risque"/0 pour les classes non
          assignees), jamais retomber sur le calcul brut/pourcentage.
        - value_risk_map : dict {valeur: nom_du_niveau} pour les classes
          auxquelles un niveau de risque reel (autre que "Aucun risque")
          a ete assigne. Peut etre un dict VIDE (et non None) si
          classified=True mais qu'aucune classe n'a de niveau -- distinct
          du cas non classe (classified=False), ou value_risk_map vaut
          toujours None.
        - value_labels : dict {valeur: nom_de_classe} pour TOUTES les
          valeurs nommees (sert aussi bien au calcul qu'a la legende),
          ou None si non classe.
        - value_comments : dict {valeur: texte_du_commentaire} pour les
          classes ayant un commentaire de cause renseigne (ex: 'Espace
          anciennement jachere'), ou None si non classe."""
        if self.no_class_check.isChecked():
            return None, None, None, False

        value_risk_map = {}
        value_labels = {}
        value_comments = {}
        for row in range(self.table.rowCount()):
            value_text = self.table.item(row, 0).text().strip() if self.table.item(row, 0) else ""
            if not value_text:
                continue
            try:
                value = float(value_text)
            except ValueError:
                continue

            name_item = self.table.item(row, 1)
            label = name_item.text().strip() if name_item else ""
            if label:
                value_labels[value] = label

            combo = self.table.cellWidget(row, 2)
            level = combo.currentText() if combo else "Aucun risque"
            if level != "Aucun risque":
                value_risk_map[value] = level

            comment_item = self.table.item(row, 3)
            comment = comment_item.text().strip() if comment_item else ""
            if comment:
                value_comments[value] = comment

        # IMPORTANT : contrairement a avant, on NE remplace PLUS
        # value_risk_map vide par None ici -- un dict vide signifie
        # "classe, mais aucune classe a risque", ce qui doit rester
        # distingue du "non classe" (classified=False). C'est cette
        # distinction qui garantit que le calcul reste base sur les
        # classes (et non sur le seuil/pourcentage brut) des qu'un
        # raster a ete configure.
        return value_risk_map, (value_labels or None), (value_comments or None), True


# ----------------------------------------------------------------------
# Dialogue principal du plugin
# ----------------------------------------------------------------------
class RiskDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("Analyse de risque de deforestation")
        self.resize(560, 600)

        # couches de reference ajoutees par l'utilisateur : liste de dicts
        # {"layer", "type": "raster"|"vector", "prefix",
        #  "class_field" (vecteur, optionnel), "risk_values" (optionnel)}
        self.reference_layers = []
        self.result_layer = None
        self._cancel_requested = False
        self._last_analysis_datetime = None
        self._feedback = None
        # Caches de configuration par couche (cle = layer.id()), pour que
        # les parametres deja saisis (noms, niveaux, commentaires) soient
        # conserves par defaut si la meme couche est reutilisee plus tard
        # (ex: via "Utiliser un raster/vecteur deja charge").
        self._raster_class_cache = {}
        self._vector_class_cache = {}

        self._build_ui()

    # ------------------------------------------------------------------
    def _build_ui(self):
        main_layout = QVBoxLayout()

        # --- Section parcelles ---
        parcel_box = QGroupBox("1. Couche à analyser")
        parcel_layout = QVBoxLayout()

        hint_label = QLabel("Veuillez ajouter ici la couche à analyser.")
        hint_label.setWordWrap(True)
        parcel_layout.addWidget(hint_label)

        self.layer_combo = QgsMapLayerComboBox()
        self.layer_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        parcel_layout.addWidget(self.layer_combo)

        id_row = QHBoxLayout()
        id_row.addWidget(QLabel("Champ identifiant (optionnel) :"))
        self.id_field_combo = QgsFieldComboBox()
        self.id_field_combo.setLayer(self.layer_combo.currentLayer())
        self.layer_combo.layerChanged.connect(self.id_field_combo.setLayer)
        id_row.addWidget(self.id_field_combo)
        parcel_layout.addLayout(id_row)

        parcel_box.setLayout(parcel_layout)
        main_layout.addWidget(parcel_box)

        # --- Section couches de reference ---
        ref_box = QGroupBox(
            "2. Couches de reference / verification (cocher celles a analyser)"
        )
        ref_layout = QVBoxLayout()

        btn_row = QHBoxLayout()
        self.btn_add_layer = QPushButton("Ajouter couche...")
        self.btn_add_layer.setToolTip(
            "Ajouter un ou plusieurs fichiers locaux (raster .tif et/ou "
            "shapefile .shp) comme couche(s) de reference."
        )
        self.btn_add_layer.clicked.connect(self.open_add_layer_picker)
        btn_row.addWidget(self.btn_add_layer)

        self.btn_download_raster = QPushButton("Telecharger raster...")
        self.btn_download_raster.setToolTip(
            "Ajouter une couche raster de reference telechargeable "
            "automatiquement : ESA WorldCover (lecture distante, sans "
            "telechargement complet) et/ou Hansen GFC (telechargement des "
            "tuiles couvrant l'emprise des parcelles, avec mise en cache)."
        )
        self.btn_download_raster.clicked.connect(self.open_download_raster_picker)
        btn_row.addWidget(self.btn_download_raster)

        self.btn_use_existing = QPushButton("Utiliser couche deja chargee...")
        self.btn_use_existing.setToolTip(
            "Reutiliser une couche raster et/ou vecteur deja ouverte dans "
            "QGIS, sans repasser par l'explorateur de fichiers."
        )
        self.btn_use_existing.clicked.connect(self.open_use_existing_picker)
        btn_row.addWidget(self.btn_use_existing)
        ref_layout.addLayout(btn_row)

        self.ref_list = QListWidget()
        ref_layout.addWidget(self.ref_list)

        list_btn_row = QHBoxLayout()
        self.btn_remove_ref = QPushButton("Retirer la couche selectionnee")
        self.btn_configure_ref = QPushButton("Configurer les classes...")
        list_btn_row.addWidget(self.btn_remove_ref)
        list_btn_row.addWidget(self.btn_configure_ref)
        ref_layout.addLayout(list_btn_row)

        ref_box.setLayout(ref_layout)
        main_layout.addWidget(ref_box)

        # --- Section seuil / score ---
        threshold_box = QGroupBox("3. Seuil de risque")
        threshold_layout = QHBoxLayout()
        threshold_layout.addWidget(
            QLabel("Seuil (%) au-dela duquel une parcelle est classee 'Élevé' :")
        )
        self.threshold_spin = QDoubleSpinBox()
        self.threshold_spin.setRange(0.0, 100.0)
        self.threshold_spin.setValue(5.0)
        self.threshold_spin.setSuffix(" %")
        threshold_layout.addWidget(self.threshold_spin)
        threshold_box.setLayout(threshold_layout)
        main_layout.addWidget(threshold_box)

        # --- Progress + actions ---
        self.progress = QProgressBar()
        self.progress.setValue(0)
        main_layout.addWidget(self.progress)

        action_row = QHBoxLayout()
        self.btn_run = QPushButton("Lancer l'analyse")
        self.btn_cancel = QPushButton("Annuler")
        self.btn_cancel.setEnabled(False)
        self.btn_report = QPushButton("Generer un rapport Excel...")
        self.btn_report.setEnabled(False)
        action_row.addWidget(self.btn_run)
        action_row.addWidget(self.btn_cancel)
        action_row.addWidget(self.btn_report)
        main_layout.addLayout(action_row)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        main_layout.addWidget(self.status_label)

        self.setLayout(main_layout)

        # signaux
        self.btn_remove_ref.clicked.connect(self.remove_selected_ref)
        self.btn_configure_ref.clicked.connect(self.configure_selected_ref)
        self.btn_run.clicked.connect(self.run_analysis)
        self.btn_cancel.clicked.connect(self.request_cancel)
        self.btn_report.clicked.connect(self.generate_report)

    # ------------------------------------------------------------------
    def _entry_label(self, entry):
        base = f"[{entry['type'].upper()}] {entry['layer'].name()}"
        value_labels = entry.get("value_labels") or {}
        value_risk_map = entry.get("value_risk_map") or {}

        if entry.get("class_field") and entry.get("risk_values"):
            classes = ", ".join(entry["risk_values"])
            base += f"  -> {entry['class_field']} in ({classes})"
            if entry.get("comment"):
                base += f"  [{entry['comment']}]"
        elif value_risk_map:  # raster : niveau de risque par classe
            parts = []
            for v, level in value_risk_map.items():
                name = value_labels.get(v)
                parts.append(f"{name or v}: {level}")
            base += f"  -> {', '.join(parts)}"
            if entry.get("value_comments"):
                base += f"  [{len(entry['value_comments'])} commentaire(s)]"
        elif entry.get("raster_classified"):
            # Raster classe, mais aucune classe n'a recu de niveau reel :
            # distinct du mode "valeurs brutes" (non classe du tout).
            base += "  -> classe, mais aucun niveau assigne (Aucun risque)"
        else:
            base += "  -> couche entiere / valeurs brutes"
        return base

    def _add_reference_entry(
        self, layer, layer_type, class_field=None, risk_values=None,
        value_labels=None, value_risk_map=None, comment=None, value_comments=None,
        raster_classified=False,
    ):
        prefix = self._make_safe_prefix(layer.name())
        entry = {
            "layer": layer,
            "type": layer_type,
            "prefix": prefix,
            "class_field": class_field,
            "risk_values": risk_values,
            "value_labels": value_labels,
            "value_risk_map": value_risk_map,
            "comment": comment,
            "value_comments": value_comments,
            "raster_classified": raster_classified,
        }
        self.reference_layers.append(entry)

        item = QListWidgetItem(self._entry_label(entry))
        item.setFlags(item.flags() | ITEM_USER_CHECKABLE)
        item.setCheckState(CHECK_CHECKED)
        item.setData(DATA_USER_ROLE, len(self.reference_layers) - 1)
        self.ref_list.addItem(item)

    def _make_safe_prefix(self, name):
        """Construit un prefixe de champ court (<= 8 caracteres utiles)
        a partir du nom de la couche. IMPORTANT : verifie l'unicite par
        rapport aux couches de reference deja ajoutees dans CETTE analyse
        -- deux rasters dont le nom commence de la meme facon (ex. "Unite
        d'occupation du sol BNETD" et "Unite d'occupation du sol 2020")
        tronqueraient sinon vers le MEME prefixe, ce qui fait que leurs
        champs de resultat (et niveaux de risque) s'ecrasent mutuellement
        au lieu de rester separes. En cas de collision, un suffixe
        numerique (2, 3...) est ajoute jusqu'a obtenir un prefixe libre."""
        cleaned = "".join(c for c in name if c.isalnum())[:8]
        base = (cleaned or "ref").lower()
        existing = {e["prefix"] for e in self.reference_layers}

        candidate = base + "_"
        if candidate not in existing:
            return candidate

        i = 2
        while True:
            candidate = f"{base}{i}_"
            if candidate not in existing:
                return candidate
            i += 1

    @staticmethod
    def _raster_cache_from_results(value_labels, value_risk_map, value_comments):
        """Construit l'entree de cache {valeur: {label, level, comment}} a
        partir des resultats de RasterClassDialog, pour pre-remplir la
        fenetre si la meme couche est reutilisee plus tard."""
        value_labels = value_labels or {}
        value_risk_map = value_risk_map or {}
        value_comments = value_comments or {}
        all_values = set(value_labels) | set(value_risk_map) | set(value_comments)
        return {
            v: {
                "label": value_labels.get(v, ""),
                "level": value_risk_map.get(v),
                "comment": value_comments.get(v, ""),
            }
            for v in all_values
        }

    def _get_raster_initial_config(self, layer):
        return self._raster_class_cache.get(layer.id())

    def _store_raster_cache(self, layer, value_labels, value_risk_map, value_comments):
        cache_entry = self._raster_cache_from_results(
            value_labels, value_risk_map, value_comments
        )
        if cache_entry:
            self._raster_class_cache[layer.id()] = cache_entry

    def _get_vector_initial_config(self, layer):
        return self._vector_class_cache.get(layer.id())

    def _store_vector_cache(self, layer, class_field, risk_values, comment):
        if class_field and risk_values:
            self._vector_class_cache[layer.id()] = (class_field, risk_values, comment)

    # ------------------------------------------------------------------
    def add_hansen_gfc(self):
        parcel_layer = self.layer_combo.currentLayer()
        if parcel_layer is None:
            QMessageBox.warning(
                self, "Erreur",
                "Choisis d'abord une couche de parcelles (section 1)."
            )
            return

        try:
            xmin, ymin, xmax, ymax = risk_engine.get_layer_extent_wgs84(parcel_layer)
            tiles = hd.tiles_for_extent(xmin, ymin, xmax, ymax)
        except Exception:
            QMessageBox.critical(
                self, "Erreur inattendue",
                "Echec lors du calcul de l'emprise :\n\n" + traceback.format_exc()
            )
            return

        if not tiles:
            QMessageBox.warning(self, "Erreur", "Aucune tuile Hansen trouvee pour cette emprise.")
            return
        if len(tiles) > hd.MAX_TILES:
            QMessageBox.warning(
                self, "Emprise trop vaste",
                f"{len(tiles)} tuiles Hansen seraient necessaires (max {hd.MAX_TILES}). "
                "Verifie que la couche de parcelles selectionnee est la bonne."
            )
            return

        include_treecover = QMessageBox.question(
            self, "Couvert forestier 2000",
            "Inclure aussi le raster 'treecover2000' (couvert forestier initial), "
            "en plus de 'lossyear' (annee de perte) ?\n\n"
            "Utile pour ne compter la perte que sur la foret dense (seuil FAO 10%).",
        ) == _compat_enum(QMessageBox, "StandardButton.Yes", "Yes")

        layers_to_fetch = ["lossyear"] + (["treecover2000"] if include_treecover else [])
        added_any = False

        for layer_kind in layers_to_fetch:
            self.status_label.setText(f"Telechargement Hansen GFC : {layer_kind}...")
            QApplication.processEvents()

            def _progress(pct):
                QApplication.processEvents()

            def _log(msg):
                self.status_label.setText(msg)
                QApplication.processEvents()

            try:
                path, _available = hd.ensure_layer(
                    tiles, layer_kind, hd.DEFAULT_VERSION,
                    progress_cb=_progress, log_cb=_log,
                )
            except Exception:
                QMessageBox.critical(
                    self, "Erreur inattendue",
                    f"Echec du telechargement Hansen ({layer_kind}) :\n\n"
                    + traceback.format_exc()
                )
                continue

            if not path:
                QMessageBox.warning(
                    self, "Erreur",
                    f"Aucune tuile Hansen disponible pour '{layer_kind}' sur cette emprise."
                )
                continue

            layer = QgsRasterLayer(path, f"Hansen GFC -- {layer_kind}")
            if not layer.isValid():
                detail = layer.error().message() if layer.error() else "raison inconnue"
                QMessageBox.warning(
                    self, "Erreur",
                    f"Raster Hansen invalide ({layer_kind}) : {detail}"
                )
                continue

            if layer_kind == "lossyear":
                raster_style.style_hansen_lossyear(layer)
            elif layer_kind == "treecover2000":
                raster_style.style_treecover(layer)

            QgsProject.instance().addMapLayer(layer)
            self._add_reference_entry(layer, "raster")
            added_any = True

        self.status_label.setText(
            "Hansen GFC ajoute. Utilise 'Configurer les classes...' pour assigner un "
            "niveau de risque par annee (ex: annees > 2020 = Tres eleve)."
            if added_any else "Aucune couche Hansen ajoutee."
        )

    def add_esa_worldcover(self):
        parcel_layer = self.layer_combo.currentLayer()
        if parcel_layer is None:
            QMessageBox.warning(
                self, "Erreur",
                "Choisis d'abord une couche de parcelles (section 1)."
            )
            return

        try:
            xmin, ymin, xmax, ymax = risk_engine.get_layer_extent_wgs84(parcel_layer)
            self.status_label.setText("Ajout ESA WorldCover (lecture distante)...")
            QApplication.processEvents()
            layer = extra_sources.add_worldcover(
                xmin, ymin, xmax, ymax, year=2020,
                log_cb=lambda msg: (self.status_label.setText(msg), QApplication.processEvents()),
            )
        except Exception:
            QMessageBox.critical(
                self, "Erreur inattendue",
                "Echec lors de l'ajout d'ESA WorldCover :\n\n" + traceback.format_exc()
            )
            return

        if layer is None:
            QMessageBox.warning(
                self, "Erreur",
                "Impossible d'ajouter ESA WorldCover (reseau, ou emprise invalide)."
            )
            return

        raster_style.style_worldcover(layer)
        QgsProject.instance().addMapLayer(layer)
        self._add_reference_entry(layer, "raster")
        self.status_label.setText(
            "ESA WorldCover 2020 ajoute. Classes : 10=Foret, 20=Arbustes, 30=Prairie, "
            "40=Cultures, 50=Bati, 60=Sol nu, 80=Eau, 90=Zone humide, 95=Mangrove."
        )

    def open_add_layer_picker(self):
        dlg = MultiChoiceLauncherDialog(
            "Ajouter couche",
            "Cocher le(s) type(s) de fichier a ajouter :",
            [("raster", "Raster (.tif)"), ("vector", "Vecteur (Shapefile .shp)")],
            self,
        )
        if _exec_dialog(dlg) != DIALOG_ACCEPTED:
            return
        selected = dlg.get_selected_keys()
        if "raster" in selected:
            self.add_raster_files()
        if "vector" in selected:
            self.add_vector_files()

    def open_download_raster_picker(self):
        dlg = MultiChoiceLauncherDialog(
            "Telecharger raster",
            "Cocher la ou les couches a ajouter :",
            [("worldcover", "ESA WorldCover (COG, lecture distante)"),
             ("hansen", "Hansen GFC (telechargement auto)")],
            self,
        )
        if _exec_dialog(dlg) != DIALOG_ACCEPTED:
            return
        selected = dlg.get_selected_keys()
        if "worldcover" in selected:
            self.add_esa_worldcover()
        if "hansen" in selected:
            self.add_hansen_gfc()

    def open_use_existing_picker(self):
        dlg = MultiChoiceLauncherDialog(
            "Utiliser couche deja chargee",
            "Cocher le(s) type(s) de couche a reutiliser :",
            [("raster", "Raster"), ("vector", "Vecteur")],
            self,
        )
        if _exec_dialog(dlg) != DIALOG_ACCEPTED:
            return
        selected = dlg.get_selected_keys()
        if "raster" in selected:
            self.use_existing_raster()
        if "vector" in selected:
            self.use_existing_vector()

    def add_raster_files(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Selectionner un ou plusieurs rasters (.tif)", "", "GeoTIFF (*.tif *.tiff)"
        )
        for path in paths:
            try:
                name = os.path.splitext(os.path.basename(path))[0]
                layer = QgsRasterLayer(path, name)
                if not layer.isValid():
                    detail = layer.error().message() if layer.error() else "raison inconnue"
                    QMessageBox.warning(
                        self, "Raster invalide",
                        f"Impossible de charger : {path}\n\nDetail : {detail}"
                    )
                    continue
                QgsProject.instance().addMapLayer(layer)

                dlg = RasterClassDialog(
                    layer, self, initial_config=self._get_raster_initial_config(layer)
                )
                value_risk_map, value_labels, value_comments, classified = None, None, None, False
                if _exec_dialog(dlg) == DIALOG_ACCEPTED:
                    value_risk_map, value_labels, value_comments, classified = dlg.get_result()
                    self._store_raster_cache(layer, value_labels, value_risk_map, value_comments)

                if value_labels:
                    risk_engine.apply_class_symbology(layer, value_labels, value_risk_map)

                self._add_reference_entry(
                    layer, "raster", value_labels=value_labels,
                    value_risk_map=value_risk_map, value_comments=value_comments,
                    raster_classified=classified,
                )
            except Exception:
                QMessageBox.critical(
                    self, "Erreur inattendue",
                    f"Echec lors de l'ajout du raster '{path}' :\n\n" + traceback.format_exc()
                )

    def add_vector_files(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Selectionner un ou plusieurs shapefiles (.shp)", "", "Shapefile (*.shp)"
        )
        for path in paths:
            try:
                name = os.path.splitext(os.path.basename(path))[0]
                layer = QgsVectorLayer(path, name, "ogr")
                if not layer.isValid():
                    detail = layer.error().message() if layer.error() else "raison inconnue"
                    QMessageBox.warning(
                        self, "Shapefile invalide",
                        f"Impossible de charger : {path}\n\nDetail : {detail}"
                    )
                    continue
                QgsProject.instance().addMapLayer(layer)

                dlg = VectorClassDialog(
                    layer, self, initial_config=self._get_vector_initial_config(layer)
                )
                class_field, risk_values, comment = None, None, None
                if _exec_dialog(dlg) == DIALOG_ACCEPTED:
                    class_field, risk_values, comment = dlg.get_result()
                    self._store_vector_cache(layer, class_field, risk_values, comment)

                self._add_reference_entry(
                    layer, "vector", class_field=class_field, risk_values=risk_values,
                    comment=comment,
                )
            except Exception:
                QMessageBox.critical(
                    self, "Erreur inattendue",
                    f"Echec lors de l'ajout du shapefile '{path}' :\n\n" + traceback.format_exc()
                )

    def use_existing_raster(self):
        picker = ExistingLayerPickerDialog(
            QgsMapLayerProxyModel.RasterLayer,
            "Choisir un raster deja charge",
            self,
        )
        if _exec_dialog(picker) != DIALOG_ACCEPTED:
            return
        layer = picker.get_result()
        if layer is None:
            QMessageBox.information(
                self, "Info", "Aucune couche raster n'est actuellement chargee dans QGIS."
            )
            return
        try:
            dlg = RasterClassDialog(
                layer, self, initial_config=self._get_raster_initial_config(layer)
            )
            value_risk_map, value_labels, value_comments, classified = None, None, None, False
            if _exec_dialog(dlg) == DIALOG_ACCEPTED:
                value_risk_map, value_labels, value_comments, classified = dlg.get_result()
                self._store_raster_cache(layer, value_labels, value_risk_map, value_comments)

            if value_labels:
                risk_engine.apply_class_symbology(layer, value_labels, value_risk_map)

            self._add_reference_entry(
                layer, "raster", value_labels=value_labels,
                value_risk_map=value_risk_map, value_comments=value_comments,
                raster_classified=classified,
            )
        except Exception:
            QMessageBox.critical(
                self, "Erreur inattendue",
                f"Echec lors de l'utilisation du raster '{layer.name()}' :\n\n"
                + traceback.format_exc()
            )

    def use_existing_vector(self):
        picker = ExistingLayerPickerDialog(
            QgsMapLayerProxyModel.VectorLayer,
            "Choisir une couche vecteur deja chargee",
            self,
        )
        if _exec_dialog(picker) != DIALOG_ACCEPTED:
            return
        layer = picker.get_result()
        if layer is None:
            QMessageBox.information(
                self, "Info", "Aucune couche vecteur n'est actuellement chargee dans QGIS."
            )
            return
        try:
            dlg = VectorClassDialog(
                layer, self, initial_config=self._get_vector_initial_config(layer)
            )
            class_field, risk_values, comment = None, None, None
            if _exec_dialog(dlg) == DIALOG_ACCEPTED:
                class_field, risk_values, comment = dlg.get_result()
                self._store_vector_cache(layer, class_field, risk_values, comment)

            self._add_reference_entry(
                layer, "vector", class_field=class_field, risk_values=risk_values,
                comment=comment,
            )
        except Exception:
            QMessageBox.critical(
                self, "Erreur inattendue",
                f"Echec lors de l'utilisation de la couche '{layer.name()}' :\n\n"
                + traceback.format_exc()
            )

    def remove_selected_ref(self):
        row = self.ref_list.currentRow()
        if row < 0:
            return
        self.ref_list.takeItem(row)
        del self.reference_layers[row]
        # ré-indexer les UserRole restants
        for i in range(self.ref_list.count()):
            self.ref_list.item(i).setData(DATA_USER_ROLE, i)

    def configure_selected_ref(self):
        row = self.ref_list.currentRow()
        if row < 0:
            QMessageBox.information(self, "Info", "Selectionnez d'abord une couche dans la liste.")
            return

        entry = self.reference_layers[row]
        if entry["type"] == "vector":
            current_config = (
                entry.get("class_field"), entry.get("risk_values"), entry.get("comment")
            )
            dlg = VectorClassDialog(entry["layer"], self, initial_config=current_config)
            if _exec_dialog(dlg) == DIALOG_ACCEPTED:
                class_field, risk_values, comment = dlg.get_result()
                entry["class_field"] = class_field
                entry["risk_values"] = risk_values
                entry["comment"] = comment
                self._store_vector_cache(entry["layer"], class_field, risk_values, comment)
        else:
            current_config = self._raster_cache_from_results(
                entry.get("value_labels"), entry.get("value_risk_map"), entry.get("value_comments")
            )
            dlg = RasterClassDialog(entry["layer"], self, initial_config=current_config)
            if _exec_dialog(dlg) == DIALOG_ACCEPTED:
                value_risk_map, value_labels, value_comments, classified = dlg.get_result()
                entry["value_risk_map"] = value_risk_map
                entry["value_labels"] = value_labels
                entry["value_comments"] = value_comments
                entry["raster_classified"] = classified
                self._store_raster_cache(
                    entry["layer"], value_labels, value_risk_map, value_comments
                )
                if value_labels:
                    risk_engine.apply_class_symbology(
                        entry["layer"], value_labels, value_risk_map
                    )

        self.ref_list.item(row).setText(self._entry_label(entry))

    # ------------------------------------------------------------------
    def _checked_reference_layers(self):
        checked = []
        for i in range(self.ref_list.count()):
            item = self.ref_list.item(i)
            if item.checkState() == CHECK_CHECKED:
                idx = item.data(DATA_USER_ROLE)
                checked.append(self.reference_layers[idx])
        return checked

    def request_cancel(self):
        self._cancel_requested = True
        if self._feedback is not None:
            # Signale l'annulation aux appels QGIS/GDAL en cours (decoupe,
            # reclassification, statistiques zonales) : ces operations
            # verifient periodiquement cet objet et peuvent s'arreter
            # avant leur fin naturelle, au lieu d'ignorer completement le
            # bouton Annuler comme c'etait le cas auparavant.
            self._feedback.cancel()
        self.status_label.setText(
            "Annulation demandee... l'arret peut prendre quelques secondes "
            "le temps que l'operation en cours (decoupe/reclassification/"
            "statistiques) detecte la demande."
        )
        QApplication.processEvents()

    def _should_cancel(self):
        QApplication.processEvents()  # garde l'interface reactive pendant les boucles
        return self._cancel_requested

    def run_analysis(self):
        parcel_layer = self.layer_combo.currentLayer()
        if parcel_layer is None:
            QMessageBox.warning(self, "Erreur", "Choisissez une couche de parcelles.")
            return

        active_refs = self._checked_reference_layers()
        if not active_refs:
            QMessageBox.warning(
                self, "Erreur",
                "Cochez au moins une couche de reference (GFC2020, TIF ou SHP)."
            )
            return

        wms_names = [
            ref["layer"].name() for ref in active_refs
            if ref["type"] == "raster"
            and (ref["layer"].providerType() or "").lower() == "wms"
        ]
        if wms_names:
            proceed = QMessageBox.question(
                self, "Couche WMS detectee",
                "Les couches suivantes sont des flux WMS (reseau), pas des "
                "fichiers locaux : " + ", ".join(wms_names) + ".\n\n"
                "Le calcul zonal sur un flux WMS est nettement plus lent "
                "(chaque parcelle declenche des requetes internet) et ne "
                "peut pas etre accelere par decoupe locale. Pour de gros "
                "volumes, il est preferable de telecharger la couche en "
                "GeoTIFF et de l'ajouter via 'Ajouter raster (.tif)'.\n\n"
                "Continuer quand meme avec le WMS ?"
            )
            if proceed != _compat_enum(QMessageBox, "StandardButton.Yes", "Yes"):
                return

        self._cancel_requested = False
        self._feedback = QgsProcessingFeedback()
        self.btn_run.setEnabled(False)
        self.btn_cancel.setEnabled(True)

        try:
            self.status_label.setText("Copie de la couche de parcelles en memoire...")
            self.progress.setValue(5)
            QApplication.processEvents()

            try:
                working_layer = risk_engine.clone_vector_layer_to_memory(
                    parcel_layer, name="parcelles_risque"
                )
            except Exception:
                QMessageBox.critical(
                    self, "Erreur inattendue",
                    "Echec lors de la copie de la couche de parcelles en memoire "
                    ":\n\n" + traceback.format_exc()
                )
                self.status_label.setText("Analyse interrompue (voir message d'erreur).")
                return

            indicator_fields = []
            indicator_specs = []
            layer_comment_specs = {}  # prefix de couche -> liste (champ, texte)
            temp_comment_fields = []
            comment_counter = 0
            total = len(active_refs)

            for i, ref in enumerate(active_refs, start=1):
                if self._cancel_requested:
                    self.status_label.setText(
                        f"Analyse annulee avant la couche '{ref['layer'].name()}'. "
                        f"{len(indicator_fields)}/{total} couche(s) deja traitee(s)."
                    )
                    return

                self.status_label.setText(
                    f"Traitement : {ref['layer'].name()} ({i}/{total})..."
                )
                self.progress.setValue(5 + int(70 * i / total))
                QApplication.processEvents()

                try:
                    if ref["type"] == "raster":
                        value_risk_map = ref.get("value_risk_map")
                        if ref.get("raster_classified"):
                            # Raster classe (fenetre de classification validee,
                            # "Ne pas classer" decochee) : TOUJOURS un calcul
                            # par classe, meme si value_risk_map est vide (ex:
                            # aucune classe n'a recu de niveau reel) -- dans ce
                            # cas, les pixels non assignes valent "Aucun
                            # risque" (poids 0), jamais un retour au calcul
                            # brut/pourcentage sur les valeurs de pixel.
                            field = risk_engine.compute_raster_max_risk_percentage(
                                working_layer,
                                ref["layer"],
                                ref["prefix"],
                                value_risk_map or {},
                                feedback=self._feedback,
                            )
                            indicator_specs.append((field, "weight"))
                            layer_kind = "weight"
                        else:
                            field = risk_engine.compute_raster_zonal_percentage(
                                working_layer,
                                ref["layer"],
                                ref["prefix"],
                                feedback=self._feedback,
                            )
                            indicator_specs.append((field, "percentage"))
                            layer_kind = "percentage"
                        indicator_fields.append(field)

                        per_layer_field = risk_engine.compute_single_layer_risk_score(
                            working_layer, field, layer_kind,
                            self.threshold_spin.value(), f"{ref['prefix']}risque",
                        )
                        indicator_fields.append(per_layer_field)

                        value_comments = ref.get("value_comments") or {}
                        if value_comments:
                            # Decoupe une seule fois, reutilisee pour toutes
                            # les classes commentees de cette couche (au lieu
                            # de redecouper le raster complet a chaque classe).
                            clipped_for_comments = risk_engine.clip_raster_to_layer_extent(
                                ref["layer"], working_layer, feedback=self._feedback
                            )
                            this_layer_comments = []
                            for value, comment_text in value_comments.items():
                                if self._cancel_requested:
                                    raise risk_engine.AnalysisCancelled()
                                comment_counter += 1
                                temp_prefix = f"tmpc{comment_counter}_"
                                temp_field_name = risk_engine.compute_raster_zonal_percentage(
                                    working_layer,
                                    clipped_for_comments,
                                    temp_prefix,
                                    class_values=[value],
                                    feedback=self._feedback,
                                    skip_clip=True,
                                )
                                # QgsZonalStatistics cree 3 champs (mean/sum/
                                # count) par appel -- il faut prevoir de
                                # nettoyer les 3, pas seulement 'mean'.
                                temp_comment_fields.extend([
                                    f"{temp_prefix}mean", f"{temp_prefix}sum", f"{temp_prefix}count",
                                ])
                                this_layer_comments.append((temp_field_name, comment_text))
                            layer_comment_specs[ref["prefix"]] = this_layer_comments
                    else:
                        field_name = f"{ref['prefix']}pct"
                        field = risk_engine.compute_vector_overlap_percentage(
                            working_layer,
                            ref["layer"],
                            field_name,
                            class_field=ref.get("class_field"),
                            risk_values=ref.get("risk_values"),
                            should_cancel=self._should_cancel,
                        )
                        indicator_fields.append(field)
                        indicator_specs.append((field, "percentage"))

                        per_layer_field = risk_engine.compute_single_layer_risk_score(
                            working_layer, field, "percentage",
                            self.threshold_spin.value(), f"{ref['prefix']}risque",
                        )
                        indicator_fields.append(per_layer_field)

                        if ref.get("comment"):
                            layer_comment_specs[ref["prefix"]] = [(field, ref["comment"])]
                except risk_engine.AnalysisCancelled:
                    self.status_label.setText(
                        f"Analyse annulee pendant '{ref['layer'].name()}'. "
                        f"{len(indicator_fields)}/{total} couche(s) deja traitee(s)."
                    )
                    return
                except Exception as exc:
                    QMessageBox.warning(
                        self, "Erreur de traitement",
                        f"Echec sur la couche '{ref['layer'].name()}' : {exc}"
                    )

            self.status_label.setText("Calcul du score de risque composite...")
            self.progress.setValue(85)
            QApplication.processEvents()
            risk_engine.compute_risk_score(
                working_layer, indicator_specs, threshold=self.threshold_spin.value()
            )

            self.status_label.setText("Construction des colonnes de commentaire (une par couche)...")
            self.progress.setValue(92)
            QApplication.processEvents()
            comment_fields = []
            for ref in active_refs:
                specs = layer_comment_specs.get(ref["prefix"])
                if not specs:
                    continue
                comment_field_name = f"{ref['prefix']}comment"
                risk_engine.build_comment_field(working_layer, specs, field_name=comment_field_name)
                comment_fields.append(comment_field_name)
            if temp_comment_fields:
                risk_engine.remove_fields(working_layer, temp_comment_fields)

            QgsProject.instance().addMapLayer(working_layer)
            self.result_layer = working_layer
            self._last_analysis_datetime = datetime.now()
            self.btn_report.setEnabled(True)

            self.progress.setValue(100)
            fields_msg = f"{', '.join(indicator_fields)}, risque_score, risque_max_pct"
            if comment_fields:
                fields_msg += f", {', '.join(comment_fields)}"
            self.status_label.setText(
                f"Analyse terminee : {working_layer.featureCount()} parcelles traitees "
                f"({total} couche(s) analysee(s)). "
                f"Champs ajoutes : {fields_msg}."
            )
        finally:
            self.btn_run.setEnabled(True)
            self.btn_cancel.setEnabled(False)

    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    def generate_report(self):
        if self.result_layer is None:
            return

        dlg = ReportConfigDialog(self)
        if _exec_dialog(dlg) != DIALOG_ACCEPTED:
            return
        signatory_name, logo_path, signature_path = dlg.get_result()

        path, selected_filter = QFileDialog.getSaveFileName(
            self, "Enregistrer le rapport", "", "Excel (*.xlsx)",
            "", DONT_USE_NATIVE_DIALOG,
        )
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"

        try:
            risk_counts = {
                "Très élevé": 0, "Élevé": 0, "Moyen": 0, "Faible": 0, "Très faible": 0,
                "Aucun risque": 0,
            }
            idx_score = self.result_layer.fields().indexFromName("risque_score")
            idx_maxpct = self.result_layer.fields().indexFromName("risque_max_pct")

            id_field_name = self.id_field_combo.currentField()
            idx_id = (
                self.result_layer.fields().indexFromName(id_field_name)
                if id_field_name else -1
            )

            elevated_levels = {"Très élevé", "Élevé", "Moyen"}
            severity_order = {"Très élevé": 0, "Élevé": 1, "Moyen": 2}
            at_risk_rows = []

            for feat in self.result_layer.getFeatures():
                score = feat.attribute(idx_score) if idx_score != -1 else None
                if score in risk_counts:
                    risk_counts[score] += 1

                if score in elevated_levels:
                    code = feat.attribute(idx_id) if idx_id != -1 else feat.id()
                    pct = feat.attribute(idx_maxpct) if idx_maxpct != -1 else None
                    try:
                        pct = float(pct) if pct is not None else 0.0
                    except (TypeError, ValueError):
                        pct = 0.0
                    at_risk_rows.append((str(code), score, pct))

            at_risk_rows.sort(key=lambda r: (severity_order.get(r[1], 99), -r[2]))

            reference_descriptions = [
                self._entry_label(ref) for ref in self._checked_reference_layers()
            ]

            parcel_layer = self.layer_combo.currentLayer()
            parcel_layer_name = parcel_layer.name() if parcel_layer else ""

            signatory_date = date.today().strftime("%d/%m/%Y")
            analysis_dt = self._last_analysis_datetime or datetime.now()
            analysis_datetime_str = analysis_dt.strftime("%d/%m/%Y a %H:%M")

            ok = risk_engine.export_excel_report(
                vector_layer=self.result_layer,
                output_path=path,
                title="Rapport d'analyse de risque de deforestation",
                parcel_layer_name=parcel_layer_name,
                total_parcels=self.result_layer.featureCount(),
                risk_counts=risk_counts,
                threshold=self.threshold_spin.value(),
                reference_descriptions=reference_descriptions,
                analysis_datetime=analysis_datetime_str,
                at_risk_rows=at_risk_rows,
                logo_path=logo_path,
                signature_path=signature_path,
                signatory_name=signatory_name,
                signatory_date=signatory_date,
            )
            if ok == (0, "") or ok is True:
                QMessageBox.information(
                    self, "Rapport genere", f"Rapport enregistre : {path}"
                )
            else:
                detail = ok[1] if isinstance(ok, tuple) and len(ok) > 1 else "raison inconnue"
                QMessageBox.warning(
                    self, "Erreur",
                    f"Echec de la generation du rapport Excel :\n\n{detail}"
                )
        except Exception:
            QMessageBox.critical(
                self, "Erreur inattendue",
                "Echec lors de la generation du rapport Excel :\n\n" + traceback.format_exc()
            )
