# -*- coding: utf-8 -*-
"""
plugin_log.py
=============
Journalisation centralisée des exceptions NON BLOQUANTES du plugin.

Pourquoi ce module ?
--------------------
Les traitements géométriques et les appels à l'API QGIS peuvent échouer sur des
cas isolés (géométrie corrompue, pixel hors emprise, transformation de CRS
refusée, fichier temporaire déjà supprimé…) sans que cela doive interrompre le
lot entier : on veut ignorer l'entité fautive et poursuivre.

Historiquement, cela s'écrivait `except Exception: pass` — ce qui rend l'erreur
INVISIBLE et est signalé par l'analyse de sécurité Bandit (règle B110
« Try, Except, Pass », bloquante sur plugins.qgis.org).

Ce module fournit l'alternative correcte : l'exception est ENREGISTRÉE dans le
journal des messages de QGIS (onglet « Polygon validator EUDR 2 »), le
traitement se poursuit, et l'erreur reste traçable pour l'audit et le débogage.
"""

from qgis.core import QgsMessageLog, Qgis

LOG_TAG = "Deforestation check"


def debug(context, exc):
    """
    Trace une exception non bloquante dans le journal QGIS.

    :param context: origine de l'erreur (typiquement `__name__`).
    :param exc: l'exception interceptée.
    """
    QgsMessageLog.logMessage("%s : %s" % (context, exc), LOG_TAG, Qgis.Info)


def warn(context, message):
    """Trace un avertissement non bloquant dans le journal QGIS."""
    QgsMessageLog.logMessage("%s : %s" % (context, message), LOG_TAG,
                             Qgis.Warning)
