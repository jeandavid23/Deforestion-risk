# -*- coding: utf-8 -*-
"""
raster_style.py
===============
Applique des palettes de couleurs lisibles aux rasters Hansen Global Forest
Change, pour visualiser l'occupation du sol plutôt qu'un dégradé noir & blanc.

  * lossyear   : rendu PALETTÉ par année de perte (vert = pas de perte / couvert,
                 puis jaune → rouge du plus ancien au plus récent) ;
  * treecover  : rampe verte continue (0 % clair → 100 % vert foncé).
"""

from qgis.PyQt.QtGui import QColor

from qgis.core import (
    QgsPalettedRasterRenderer, QgsRasterShader, QgsColorRampShader,
    QgsSingleBandPseudoColorRenderer,
)
from . import plugin_log


def _lerp(c1, c2, t):
    return QColor(
        int(c1.red() + (c2.red() - c1.red()) * t),
        int(c1.green() + (c2.green() - c1.green()) * t),
        int(c1.blue() + (c2.blue() - c1.blue()) * t))


def style_hansen_lossyear(layer, band=1, max_year_value=24):
    """
    Rendu paletté de la bande lossyear :
      * 0                -> vert (couvert forestier / sol, pas de perte) ;
      * 1..N (2001..)    -> jaune (ancien) vers rouge (récent).
    """
    try:
        no_loss = QColor(27, 127, 75, 120)      # vert semi-transparent
        yellow = QColor(255, 235, 120)
        orange = QColor(240, 130, 30)
        red = QColor(150, 20, 20)

        classes = [QgsPalettedRasterRenderer.Class(
            0, no_loss, "Pas de perte / couvert")]
        for v in range(1, max_year_value + 1):
            t = (v - 1) / float(max(max_year_value - 1, 1))
            if t < 0.5:
                col = _lerp(yellow, orange, t / 0.5)
            else:
                col = _lerp(orange, red, (t - 0.5) / 0.5)
            classes.append(QgsPalettedRasterRenderer.Class(
                v, col, "Perte %d" % (2000 + v)))

        renderer = QgsPalettedRasterRenderer(
            layer.dataProvider(), band, classes)
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        return True
    except Exception as exc:
        plugin_log.debug(__name__, exc)
        return False


def style_worldcover(layer, band=1):
    """Palette officielle ESA WorldCover (classes d'occupation du sol)."""
    try:
        classes = [
            (10, "#006400", "Forêt"),
            (20, "#FFBB22", "Arbustes"),
            (30, "#FFFF4C", "Prairie"),
            (40, "#F096FF", "Cultures"),
            (50, "#FA0000", "Bâti"),
            (60, "#B4B4B4", "Sol nu"),
            (70, "#F0F0F0", "Neige/glace"),
            (80, "#0064C8", "Eau"),
            (90, "#0096A0", "Zone humide"),
            (95, "#00CF75", "Mangrove"),
            (100, "#FAE6A0", "Mousse/lichen"),
        ]
        cls = [QgsPalettedRasterRenderer.Class(v, QColor(c), lbl)
               for v, c, lbl in classes]
        renderer = QgsPalettedRasterRenderer(layer.dataProvider(), band, cls)
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        return True
    except Exception as exc:
        plugin_log.debug(__name__, exc)
        return False


def style_treecover(layer, band=1):
    """Rampe verte continue pour le couvert forestier 2000 (0 → 100 %)."""
    try:
        shader = QgsRasterShader()
        ramp = QgsColorRampShader()
        ramp.setColorRampType(QgsColorRampShader.Interpolated)
        items = [
            QgsColorRampShader.ColorRampItem(0, QColor(245, 245, 235), "0 %"),
            QgsColorRampShader.ColorRampItem(10, QColor(200, 230, 180), "10 %"),
            QgsColorRampShader.ColorRampItem(30, QColor(120, 200, 120), "30 %"),
            QgsColorRampShader.ColorRampItem(60, QColor(45, 150, 70), "60 %"),
            QgsColorRampShader.ColorRampItem(100, QColor(14, 96, 46), "100 %"),
        ]
        ramp.setColorRampItemList(items)
        shader.setRasterShaderFunction(ramp)
        renderer = QgsSingleBandPseudoColorRenderer(
            layer.dataProvider(), band, shader)
        layer.setRenderer(renderer)
        layer.triggerRepaint()
        return True
    except Exception as exc:
        plugin_log.debug(__name__, exc)
        return False
