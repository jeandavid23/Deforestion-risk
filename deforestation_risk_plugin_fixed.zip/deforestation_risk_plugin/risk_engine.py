# -*- coding: utf-8 -*-
"""
risk_engine.py
Fonctions de calcul independantes de l'interface graphique :
- ajout de la couche officielle JRC GFC2020 (WMS)
- statistiques zonales sur couches raster de reference (TIF)
- pourcentage de recouvrement avec couches vectorielles de reference (SHP)
- calcul du score de risque composite par polygone
"""

from qgis.core import (
    QgsRasterLayer,
    QgsVectorLayer,
    QgsProject,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsSpatialIndex,
    QgsFeatureRequest,
    QgsExpression,
    Qgis,
    QgsPalettedRasterRenderer,
    QgsCoordinateTransform,
)
from qgis.analysis import QgsZonalStatistics
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
import processing
import colorsys
import os

# GDAL refuse parfois de creer un fichier temporaire (ex: raster reclasse
# ou decoupe) en estimant l'espace disque necessaire a partir des
# dimensions du raster SOURCE, meme lorsque la sortie reelle sera bien
# plus petite (ex: apres decoupe a l'emprise des parcelles). Sur de gros
# rasters (echelle nationale), cette estimation preventive peut depasser
# l'espace disque disponible et bloquer le traitement avec une erreur
# GDAL, alors que le traitement reel aurait reussi. On desactive donc
# cette verification preventive, comme le message d'erreur GDAL lui-meme
# le suggere.
try:
    from osgeo import gdal
    gdal.SetConfigOption("CHECK_DISK_FREE_SPACE", "FALSE")
except Exception:
    pass
os.environ.setdefault("CHECK_DISK_FREE_SPACE", "FALSE")

# Sous Qt6 (PyQt6), QVariant.Double / QVariant.String n'existent plus tels
# quels : il faut utiliser QMetaType.Type.Double / QMetaType.Type.QString.
# On resout donc les deux constantes une seule fois, en tentant QMetaType
# (Qt6) puis en repliant sur QVariant (Qt5) si indisponible.
try:
    from qgis.PyQt.QtCore import QMetaType
    FIELD_TYPE_DOUBLE = QMetaType.Type.Double
    FIELD_TYPE_STRING = QMetaType.Type.QString
except (ImportError, AttributeError):
    FIELD_TYPE_DOUBLE = QVariant.Double
    FIELD_TYPE_STRING = QVariant.String

# L'enumeration des statistiques zonales a bouge au fil des versions QGIS :
# ancien Qt5 -> QgsZonalStatistics.Mean (plat)
# Qt6 recent -> QgsZonalStatistics.Statistic.Mean (scope)
# QGIS tres recent -> Qgis.ZonalStatistic.Mean (deplace dans Qgis)
# On tente les trois dans l'ordre, du plus recent au plus ancien.
try:
    ZS_COUNT = Qgis.ZonalStatistic.Count
    ZS_SUM = Qgis.ZonalStatistic.Sum
    ZS_MEAN = Qgis.ZonalStatistic.Mean
except AttributeError:
    try:
        ZS_COUNT = QgsZonalStatistics.Statistic.Count
        ZS_SUM = QgsZonalStatistics.Statistic.Sum
        ZS_MEAN = QgsZonalStatistics.Statistic.Mean
    except AttributeError:
        ZS_COUNT = QgsZonalStatistics.Count
        ZS_SUM = QgsZonalStatistics.Sum
        ZS_MEAN = QgsZonalStatistics.Mean


class AnalysisCancelled(Exception):
    """Levee quand l'utilisateur annule une analyse en cours (bouton
    'Annuler' dans le dialogue)."""
    pass


def clone_vector_layer_to_memory(source_layer, name="parcelles_risque"):
    """Copie la couche de parcelles dans une couche memoire pour ne jamais
    modifier le fichier original (shapefile/gpkg) pendant les calculs."""
    from qgis.core import QgsWkbTypes

    # Le provider "memory" attend un mot-cle textuel ("Polygon",
    # "MultiPolygon", "PolygonZ"...), pas la valeur brute de wkbType()
    # (qui est un entier/enum et rendait la couche invalide).
    geom_type_str = QgsWkbTypes.displayString(source_layer.wkbType())

    mem_layer = QgsVectorLayer(
        f"{geom_type_str}?crs={source_layer.crs().authid()}",
        name,
        "memory",
    )
    if not mem_layer.isValid():
        raise RuntimeError(
            "Impossible de creer la couche memoire pour l'analyse "
            f"(type de geometrie detecte : '{geom_type_str}')."
        )

    mem_provider = mem_layer.dataProvider()
    mem_provider.addAttributes(source_layer.fields())
    mem_layer.updateFields()

    features = list(source_layer.getFeatures())
    mem_provider.addFeatures(features)
    mem_layer.updateExtents()
    return mem_layer


def reclassify_raster_by_values(raster_layer, class_values, band=1, feedback=None):
    """Reclasse un raster de classes (ex: classification Landsat avec des
    codes 1=Foret primaire, 2=Jachere, 3=Sol nu...) en un raster binaire :
    100 pour les pixels dont la valeur figure dans class_values, 0
    ailleurs (echelle 0-100, coherente avec le reste du pipeline qui
    manipule des pourcentages -- une echelle 0/1 provoquait une confusion
    avec les seuils de detection exprimes en %, faisant rater toute
    superposition couvrant moins de 50% de la parcelle).
    feedback (QgsFeedback/QgsProcessingFeedback optionnel) permet
    d'annuler ce traitement en cours de route (bouton 'Annuler').
    Retourne un nouveau QgsRasterLayer (fichier temporaire)."""
    table = []
    for v in class_values:
        v = float(v)
        table.extend([v - 0.5, v + 0.5, 100])
    # regle de repli : tout le reste (y compris nodata reel) -> 0
    table.extend([-1e12, 1e12, 0])

    result = processing.run(
        "native:reclassifybytable",
        {
            "INPUT_RASTER": raster_layer,
            "RASTER_BAND": band,
            "TABLE": table,
            "NO_DATA": -9999,
            "RANGE_BOUNDARIES": 0,
            "NODATA_FOR_MISSING": False,
            "DATA_TYPE": 5,  # Float32
            "OUTPUT": "TEMPORARY_OUTPUT",
        },
        feedback=feedback,
    )
    reclass_path = result["OUTPUT"]
    return QgsRasterLayer(reclass_path, raster_layer.name() + "_classes")


# Echelle de niveaux de risque, du plus sur au plus critique. L'ordre de
# cette liste sert de reference partout dans le plugin (menus deroulants,
# poids numeriques, couleurs). Ce sont les 5 niveaux SELECTIONNABLES ;
# "Aucun risque" (classe non configuree / case laissee sur ce choix par
# defaut) est gere a part, voir RISK_TIER_ORDER plus bas.
RISK_LEVELS = ["Très faible", "Faible", "Moyen", "Élevé", "Très élevé"]

# Poids numerique (0-100) associe a chaque niveau REELLEMENT choisi par
# l'utilisateur. Important : "Aucun risque" n'a volontairement PAS
# d'entree ici (il vaut 0 par defaut via .get(level, 0.0)), et "Très
# faible" commence a 20 (pas 0) -- sinon une classe explicitement mise a
# "Très faible" serait indiscernable d'une classe jamais configuree.
RISK_LEVEL_WEIGHTS = {
    "Très faible": 20.0,
    "Faible": 40.0,
    "Moyen": 60.0,
    "Élevé": 80.0,
    "Très élevé": 100.0,
}

# Palette de couleurs (rouge = critique, vert = sur), coherente avec les
# conventions cartographiques habituelles pour le risque.
RISK_LEVEL_COLORS = {
    "Aucun risque": QColor(200, 200, 200),
    "Très faible": QColor(26, 152, 80),
    "Faible": QColor(145, 207, 96),
    "Moyen": QColor(255, 230, 90),
    "Élevé": QColor(252, 141, 89),
    "Très élevé": QColor(215, 48, 39),
}
RISK_LEVEL_DEFAULT_COLOR = QColor(200, 200, 200)  # classes non evaluees

# Echelle complete utilisee pour le CLASSEMENT (rang), incluant "Aucun
# risque" tout en bas -- distinct de "Très faible", qui est desormais un
# vrai niveau choisi explicitement, pas une valeur de repli.
RISK_TIER_ORDER = ["Aucun risque"] + RISK_LEVELS


def reclassify_raster_by_risk(raster_layer, value_risk_map, band=1, feedback=None):
    """Reclasse un raster de classes en une couche de POIDS DE RISQUE
    (0-100), a partir d'un dict {valeur_pixel: nom_du_niveau}. Les valeurs
    non presentes dans value_risk_map sont mises a 0 (aucun risque connu).
    feedback (QgsFeedback/QgsProcessingFeedback optionnel) permet
    d'annuler ce traitement en cours de route.
    Retourne un nouveau QgsRasterLayer (fichier temporaire) dont la moyenne
    zonale donne directement un score de risque pondere par parcelle."""
    table = []
    for value, level in value_risk_map.items():
        weight = RISK_LEVEL_WEIGHTS.get(level, 0.0)
        v = float(value)
        table.extend([v - 0.5, v + 0.5, weight])
    table.extend([-1e12, 1e12, 0])  # repli : classes non notees -> 0

    result = processing.run(
        "native:reclassifybytable",
        {
            "INPUT_RASTER": raster_layer,
            "RASTER_BAND": band,
            "TABLE": table,
            "NO_DATA": -9999,
            "RANGE_BOUNDARIES": 0,
            "NODATA_FOR_MISSING": False,
            "DATA_TYPE": 5,  # Float32
            "OUTPUT": "TEMPORARY_OUTPUT",
        },
        feedback=feedback,
    )
    reclass_path = result["OUTPUT"]
    return QgsRasterLayer(reclass_path, raster_layer.name() + "_risque")


def get_raster_unique_values(raster_layer, band=1, max_dim=800, max_values=100):
    """Detecte les valeurs de pixel presentes dans un raster de classification
    (ex: codes Landsat 1=Foret primaire, 2=Jachere...), pour permettre a
    l'utilisateur de leur donner un nom. Pour rester rapide sur de gros
    rasters, la lecture est sous-echantillonnee a max_dim x max_dim pixels
    au maximum (suffisant pour reperer toutes les classes d'une
    classification, meme si les comptages exacts ne sont pas garantis).
    Retourne une liste triee de valeurs (float), ou une liste vide si la
    lecture echoue ou si le raster n'est visiblement pas une classification
    (plus de max_values valeurs distinctes -> probablement une image
    continue, ex: NDVI ou carbone)."""
    try:
        provider = raster_layer.dataProvider()
        extent = raster_layer.extent()
        width = raster_layer.width() or 1
        height = raster_layer.height() or 1

        if width > max_dim or height > max_dim:
            scale = max_dim / max(width, height)
            width = max(1, int(width * scale))
            height = max(1, int(height * scale))

        block = provider.block(band, extent, width, height)
        if block is None:
            return []

        values = set()
        for row in range(height):
            for col in range(width):
                if block.isNoData(row, col):
                    continue
                values.add(block.value(row, col))
                if len(values) > max_values:
                    return []  # trop de valeurs -> pas une classification
        return sorted(values)
    except Exception:
        return []


def apply_class_symbology(raster_layer, value_labels, value_risk_map=None, band=1):
    """Applique un rendu 'Paletted' au raster. Si value_risk_map est fourni
    (dict {valeur: nom_du_niveau}), la couleur de chaque classe reflete son
    NIVEAU DE RISQUE (rouge = Très élevé, vert = Très faible...), avec le nom
    de la classe en legende. Sinon, une couleur distincte arbitraire est
    utilisee (mode d'affichage simple, sans notion de risque)."""
    if not value_labels:
        return
    value_risk_map = value_risk_map or {}
    classes = []

    if value_risk_map:
        for value, label in sorted(value_labels.items()):
            level = value_risk_map.get(value)
            color = QColor(RISK_LEVEL_COLORS.get(level, RISK_LEVEL_DEFAULT_COLOR))
            display_label = f"{label} ({level})" if level else label
            classes.append(
                QgsPalettedRasterRenderer.Class(value, color, display_label or str(value))
            )
    else:
        n = max(len(value_labels), 1)
        for i, (value, label) in enumerate(sorted(value_labels.items())):
            hue = (i / n) % 1.0
            r, g, b = colorsys.hsv_to_rgb(hue, 0.65, 0.9)
            color = QColor(int(r * 255), int(g * 255), int(b * 255))
            classes.append(
                QgsPalettedRasterRenderer.Class(value, color, label or str(value))
            )

    renderer = QgsPalettedRasterRenderer(raster_layer.dataProvider(), band, classes)
    raster_layer.setRenderer(renderer)
    raster_layer.triggerRepaint()


def _extent_string(rect, crs):
    """Formate une emprise pour le parametre PROJWIN de l'algorithme GDAL,
    au format attendu par QGIS : 'xmin,xmax,ymin,ymax [AUTHID]'."""
    return (
        f"{rect.xMinimum()},{rect.xMaximum()},"
        f"{rect.yMinimum()},{rect.yMaximum()} [{crs.authid()}]"
    )


def get_layer_extent_wgs84(layer, buffer_ratio=0.02):
    """Retourne l'emprise (xmin, ymin, xmax, ymax) d'une couche reprojetee
    en WGS84 (EPSG:4326), avec une petite marge -- utilise pour determiner
    quelles tuiles telecharger (Hansen) ou quelle emprise lire a distance
    (ESA WorldCover)."""
    from qgis.core import QgsCoordinateReferenceSystem
    extent = layer.extent()
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    if layer.crs() != wgs84:
        transform = QgsCoordinateTransform(layer.crs(), wgs84, QgsProject.instance())
        extent = transform.transformBoundingBox(extent)
    dx = extent.width() * buffer_ratio or 0.01
    dy = extent.height() * buffer_ratio or 0.01
    return (
        extent.xMinimum() - dx, extent.yMinimum() - dy,
        extent.xMaximum() + dx, extent.yMaximum() + dy,
    )


def clip_raster_to_layer_extent(raster_layer, vector_layer, buffer_ratio=0.05, feedback=None):
    """Decoupe le raster a l'emprise des parcelles (avec une petite marge),
    AVANT toute reclassification/statistique zonale. Sans cette etape, un
    raster de reference couvrant une zone bien plus vaste que les parcelles
    analysees (ex: classification a l'echelle du pays) serait traite en
    entier a chaque analyse, ce qui peut multiplier le temps de calcul par
    des dizaines voire des centaines de fois pour rien.

    feedback (QgsFeedback/QgsProcessingFeedback optionnel) permet
    d'annuler ce traitement en cours de route.

    Les couches WMS (flux reseau, pas de fichier local) ne peuvent pas etre
    decoupees de cette maniere : la couche d'origine est retournee telle
    quelle dans ce cas (le calcul restera plus lent pour ce type de
    couche, voir la documentation)."""
    provider_type = (raster_layer.providerType() or "").lower()
    if provider_type == "wms":
        return raster_layer

    try:
        extent = vector_layer.extent()
        if vector_layer.crs() != raster_layer.crs():
            transform = QgsCoordinateTransform(
                vector_layer.crs(), raster_layer.crs(), QgsProject.instance()
            )
            extent = transform.transformBoundingBox(extent)

        dx = extent.width() * buffer_ratio or 0.0001
        dy = extent.height() * buffer_ratio or 0.0001
        extent.setXMinimum(extent.xMinimum() - dx)
        extent.setXMaximum(extent.xMaximum() + dx)
        extent.setYMinimum(extent.yMinimum() - dy)
        extent.setYMaximum(extent.yMaximum() + dy)

        result = processing.run(
            "gdal:cliprasterbyextent",
            {
                "INPUT": raster_layer,
                "PROJWIN": _extent_string(extent, raster_layer.crs()),
                "OVERCRS": True,
                "NODATA": None,
                "OPTIONS": "",
                "DATA_TYPE": 0,
                "EXTRA": "",
                "OUTPUT": "TEMPORARY_OUTPUT",
            },
            feedback=feedback,
        )
        clipped = QgsRasterLayer(result["OUTPUT"], raster_layer.name() + "_clip")
        if feedback is not None and feedback.isCanceled():
            raise AnalysisCancelled()
        if clipped.isValid():
            return clipped
        raise RuntimeError(
            "La couche decoupee obtenue n'est pas valide (echec silencieux de "
            "gdal:cliprasterbyextent)."
        )
    except AnalysisCancelled:
        raise
    except Exception as exc:
        # IMPORTANT : on ne retombe plus silencieusement sur le raster complet.
        # Continuer avec le raster non decoupe a deja provoque des echecs
        # bien plus graves et confus en aval (ex: GDAL reclamant ~18 Go
        # d'espace disque pour traiter un raster national en entier). Mieux
        # vaut remonter clairement l'echec de la decoupe ici.
        raise RuntimeError(
            f"Impossible de decouper le raster '{raster_layer.name()}' a "
            f"l'emprise des parcelles : {exc}"
        ) from exc


def compute_raster_zonal_percentage(
    vector_layer, raster_layer, prefix, band=1, class_values=None, value_risk_map=None,
    feedback=None, skip_clip=False,
):
    """Calcule, pour chaque polygone, la moyenne des valeurs du raster.
    - Si value_risk_map est fourni (dict {valeur: nom_du_niveau}), le raster
      est reclasse en poids de risque 0-100 selon le niveau de chaque
      classe (ex: 'Très élevé'=100, 'Faible'=25...) : la moyenne zonale
      donne alors directement un score de risque pondere par parcelle.
    - Sinon, si class_values est fourni (ancienne logique, liste de codes),
      le raster est reclasse en binaire (1 = classe a risque, 0 = le reste).
    - Sinon, les valeurs brutes du raster sont utilisees telles quelles
      (utile pour un masque deja binaire 0/1).
    feedback (QgsFeedback/QgsProcessingFeedback optionnel) permet
    d'annuler ce traitement en cours de route (decoupe, reclassification
    ET statistiques zonales verifient tous ce meme objet).
    skip_clip : si True, raster_layer est deja suppose decoupe (evite de
    redecouper inutilement plusieurs fois le meme raster, ex: quand
    compute_raster_max_risk_percentage appelle cette fonction plusieurs
    fois de suite pour les differents niveaux de risque).
    Ajoute les champs '{prefix}mean', '{prefix}sum', '{prefix}count'.
    Modifie vector_layer en place (doit etre une couche memoire ou editable)."""

    # Etape cle pour la performance : ne traiter que la zone couverte par
    # les parcelles, pas le raster en entier (qui peut couvrir une region
    # ou un pays entier alors que l'etude ne porte que sur quelques
    # centaines de polygones).
    source_raster = raster_layer if skip_clip else clip_raster_to_layer_extent(
        raster_layer, vector_layer, feedback=feedback
    )

    if value_risk_map:
        source_raster = reclassify_raster_by_risk(
            source_raster, value_risk_map, band, feedback=feedback
        )
        band = 1
    elif class_values:
        source_raster = reclassify_raster_by_values(
            source_raster, class_values, band, feedback=feedback
        )
        band = 1

    zs = QgsZonalStatistics(
        vector_layer,
        source_raster,
        prefix,
        band,
        ZS_MEAN | ZS_SUM | ZS_COUNT,
    )
    # Passer le feedback ici permet au calcul (potentiellement long, en
    # particulier sur un flux WMS) d'etre reellement interrompu par le
    # bouton 'Annuler' plutot que de devoir attendre la fin du calcul.
    zs.calculateStatistics(feedback)
    if feedback is not None and feedback.isCanceled():
        raise AnalysisCancelled()
    return f"{prefix}mean"


def compute_raster_max_risk_percentage(
    vector_layer, raster_layer, prefix, value_risk_map, band=1, feedback=None
):
    """Calcule, pour chaque polygone, le POIDS DU NIVEAU DE RISQUE LE PLUS
    ELEVE parmi les classes du raster presentes dans le polygone -- et non
    une moyenne ponderee, qui diluerait un risque localise (ex: une
    parcelle a moitie 'Jachere' (Très élevé) et a moitie 'Cacao' (Faible)
    doit etre traitee comme 'Très élevé', pas comme un score intermediaire
    factice).

    Regroupe les classes de value_risk_map par niveau (5 groupes maximum,
    un par niveau de RISK_LEVELS) et les traite du plus critique au moins
    critique : des qu'une classe a risque touche un polygone, son poids
    est retenu pour ce polygone, sauf si un niveau encore plus eleve y a
    deja ete detecte. Le raster n'est decoupe a l'emprise des parcelles
    qu'UNE SEULE FOIS (pas une fois par niveau), pour eviter de repeter un
    traitement couteux inutilement. feedback (QgsFeedback/
    QgsProcessingFeedback optionnel) permet d'annuler ce traitement en
    cours de route. Ajoute un champ '{prefix}mean' (0-100), par coherence
    avec compute_raster_zonal_percentage. Modifie vector_layer en place."""
    field_name = f"{prefix}mean"
    if vector_layer.fields().indexFromName(field_name) == -1:
        vector_layer.dataProvider().addAttributes([QgsField(field_name, FIELD_TYPE_DOUBLE)])
    vector_layer.updateFields()
    idx_field = vector_layer.fields().indexFromName(field_name)

    vector_layer.startEditing()
    for feat in vector_layer.getFeatures():
        vector_layer.changeAttributeValue(feat.id(), idx_field, 0.0)
    vector_layer.commitChanges()

    # Decoupe UNE SEULE FOIS ici, puis reutilisee pour chaque niveau
    # (au lieu de redecouper le raster complet a chaque groupe de poids).
    clipped_raster = clip_raster_to_layer_extent(raster_layer, vector_layer, feedback=feedback)

    # Regroupe les classes par poids (au plus 5 groupes : un par niveau).
    groups = {}
    for value, level in value_risk_map.items():
        weight = RISK_LEVEL_WEIGHTS.get(level, 0.0)
        groups.setdefault(weight, []).append(value)

    # Traite du poids le plus eleve au plus faible : un polygone deja
    # marque a un poids superieur n'est jamais redescendu.
    for weight in sorted(groups.keys(), reverse=True):
        if weight <= 0:
            continue  # inutile de detecter la presence d'un niveau "sans risque"
        if feedback is not None and feedback.isCanceled():
            raise AnalysisCancelled()

        # IMPORTANT : le prefixe temporaire integre le prefixe de LA
        # COUCHE elle-meme (deja garanti unique entre couches), pas
        # seulement le poids -- sinon deux rasters differents partagent
        # litteralement le meme nom de champ temporaire ("_tmpw100_..."),
        # ce qui peut faire qu'un raster traite plus tot contamine les
        # resultats d'un raster traite ensuite dans la meme analyse.
        temp_prefix = f"_{prefix}w{int(weight)}_"
        temp_field = compute_raster_zonal_percentage(
            vector_layer, clipped_raster, temp_prefix, band=band,
            class_values=groups[weight], feedback=feedback, skip_clip=True,
        )
        idx_temp = vector_layer.fields().indexFromName(temp_field)
        idx_final = vector_layer.fields().indexFromName(field_name)

        vector_layer.startEditing()
        for feat in vector_layer.getFeatures():
            current = feat.attribute(idx_final)
            current = float(current) if current is not None else 0.0
            presence = feat.attribute(idx_temp)
            presence = float(presence) if presence is not None else 0.0
            if presence > 0.5 and current < weight:
                vector_layer.changeAttributeValue(feat.id(), idx_final, float(weight))
        vector_layer.commitChanges()
        # QgsZonalStatistics cree 3 champs (mean/sum/count) pour un seul
        # appel -- il faut nettoyer les 3, pas seulement celui utilise
        # ("mean"), sinon "sum" et "count" restent definitivement dans
        # le resultat final.
        remove_fields(vector_layer, [
            f"{temp_prefix}mean", f"{temp_prefix}sum", f"{temp_prefix}count",
        ])

    return field_name


def compute_vector_overlap_percentage(
    vector_layer, ref_layer, field_name, class_field=None, risk_values=None,
    should_cancel=None,
):
    """Calcule le pourcentage de surface de chaque polygone de vector_layer
    recouvert par les geometries de ref_layer (ex: zone protegee, alerte
    RADD exportee en shapefile, concession, etc.). Ajoute un champ field_name
    (float, pourcentage 0-100) a vector_layer.

    Si class_field et risk_values sont fournis, seules les entites de
    ref_layer dont la valeur du champ class_field figure dans risk_values
    sont prises en compte (ex: ne garder que les classes 'Jachere' et
    'Sol nu' d'une classification, en ignorant 'Foret primaire').

    should_cancel : callable optionnel, appele periodiquement (toutes les
    20 parcelles). S'il retourne True, leve AnalysisCancelled et annule les
    modifications en cours (rollback), pour permettre a l'interface
    d'interrompre un calcul long sur une grosse couche de reference."""

    if vector_layer.fields().indexFromName(field_name) == -1:
        vector_layer.dataProvider().addAttributes(
            [QgsField(field_name, FIELD_TYPE_DOUBLE)]
        )
        vector_layer.updateFields()

    # Etape cle pour la performance : ne recuperer et n'indexer que les
    # entites de la couche de reference qui intersectent l'emprise des
    # parcelles, plutot que de charger toute la couche en memoire (qui
    # peut couvrir une region ou un pays entier). On reprojette aussi
    # l'emprise et les geometries si les deux couches n'ont pas le meme
    # CRS, pour eviter des intersections silencieusement fausses.
    transform_to_parcel_crs = None
    bbox = vector_layer.extent()
    if vector_layer.crs() != ref_layer.crs():
        transform_to_ref_crs = QgsCoordinateTransform(
            vector_layer.crs(), ref_layer.crs(), QgsProject.instance()
        )
        bbox = transform_to_ref_crs.transformBoundingBox(bbox)
        transform_to_parcel_crs = QgsCoordinateTransform(
            ref_layer.crs(), vector_layer.crs(), QgsProject.instance()
        )

    request = QgsFeatureRequest().setFilterRect(bbox)
    if class_field and risk_values:
        # construit une expression du type "class_field" IN ('a','b','c')
        quoted = ",".join(
            "'{}'".format(str(v).replace("'", "''")) for v in risk_values
        )
        expr = f'"{class_field}" IN ({quoted})'
        request.setFilterExpression(expr)

    ref_features = list(ref_layer.getFeatures(request))

    ref_index = QgsSpatialIndex()
    ref_geoms = {}
    for f in ref_features:
        geom = QgsGeometry(f.geometry())
        if transform_to_parcel_crs is not None:
            geom.transform(transform_to_parcel_crs)
        indexed_feat = QgsFeature(f.id())
        indexed_feat.setGeometry(geom)
        ref_index.addFeature(indexed_feat)
        ref_geoms[f.id()] = geom

    vector_layer.startEditing()
    field_idx = vector_layer.fields().indexFromName(field_name)

    for count, feat in enumerate(vector_layer.getFeatures()):
        if should_cancel is not None and count % 20 == 0 and should_cancel():
            vector_layer.rollBack()
            raise AnalysisCancelled()

        parcel_geom = feat.geometry()
        parcel_area = parcel_geom.area()
        if parcel_area <= 0:
            vector_layer.changeAttributeValue(feat.id(), field_idx, 0.0)
            continue

        candidate_ids = ref_index.intersects(parcel_geom.boundingBox())
        intersect_area = 0.0
        for cid in candidate_ids:
            ref_geom = ref_geoms.get(cid)
            if ref_geom is None:
                continue
            inter = parcel_geom.intersection(ref_geom)
            if not inter.isEmpty():
                intersect_area += inter.area()

        pct = min(100.0, (intersect_area / parcel_area) * 100.0)
        vector_layer.changeAttributeValue(feat.id(), field_idx, round(pct, 2))

    vector_layer.commitChanges()
    return field_name


def get_unique_field_values(layer, field_name):
    """Retourne la liste triee des valeurs uniques (texte) d'un champ d'une
    couche vecteur, pour peupler la fenetre de selection de classes."""
    idx = layer.fields().indexFromName(field_name)
    if idx == -1:
        return []
    values = layer.uniqueValues(idx)
    return sorted(str(v) for v in values if v is not None and str(v) != "")


_TIER_ORDER = RISK_TIER_ORDER  # ["Aucun risque", "Très faible", ..., "Très élevé"]
_TIER_RANK = {name: i for i, name in enumerate(_TIER_ORDER)}
_WEIGHT_TO_TIER = {
    0.0: "Aucun risque", 20.0: "Très faible", 40.0: "Faible",
    60.0: "Moyen", 80.0: "Élevé", 100.0: "Très élevé",
}


def _percentage_to_tier(pct, threshold):
    """Convertit un pourcentage de recouvrement (couche vecteur, ou
    raster non classe) en niveau de risque, par comparaison au seuil.
    Ne produit jamais 'Aucun risque' : ce niveau est reserve aux classes
    raster explicitement configurees mais sans niveau assigne (voir
    _weight_to_tier) -- un pourcentage de recouvrement, meme nul, reste
    une mesure reelle et se traduit par 'Très faible', pas 'Aucun
    risque'."""
    if pct > 2 * threshold:
        return "Très élevé"
    elif pct > threshold:
        return "Élevé"
    elif pct > threshold / 2:
        return "Moyen"
    elif pct > 0:
        return "Faible"
    return "Très faible"


def _weight_to_tier(weight):
    # Arrondi de securite au multiple de 20 le plus proche (les poids
    # sont normalement deja des valeurs exactes 0/20/40/60/80/100).
    rounded = round(weight / 20.0) * 20.0
    return _WEIGHT_TO_TIER.get(rounded, "Aucun risque")


def compute_risk_score(vector_layer, indicator_specs, threshold=5.0):
    """Calcule un score de risque global par polygone, sur une echelle a
    5 niveaux coherente avec RISK_LEVELS (Très faible, Faible, Moyen,
    Élevé, Très élevé). Le niveau final retenu est le PLUS ÉLEVÉ parmi
    tous les indicateurs (jamais une moyenne).

    indicator_specs est une liste de tuples (nom_du_champ, type) ou type
    vaut :
        - "weight" : le champ contient deja un poids de niveau (0/25/50/
          75/100), ex: raster classe avec compute_raster_max_risk_percentage
          -- le niveau est alors lu directement (25 -> "Faible", etc.),
          SANS repasser par le seuil en pourcentage (les deux echelles
          sont incompatibles : un poids de niveau n'est pas un % de
          recouvrement).
        - "percentage" : le champ contient un pourcentage de recouvrement
          (overlap vecteur, ou raster non classe) -- le niveau est deduit
          en comparant au seuil (et ses multiples 0.5x/2x).

    Ajoute les champs 'risque_score' (texte) et 'risque_max_pct' (float,
    la plus grande valeur brute rencontree, pour information/tri)."""

    for fname in ("risque_score", "risque_max_pct"):
        if vector_layer.fields().indexFromName(fname) == -1:
            ftype = FIELD_TYPE_STRING if fname == "risque_score" else FIELD_TYPE_DOUBLE
            vector_layer.dataProvider().addAttributes([QgsField(fname, ftype)])
    vector_layer.updateFields()

    idx_score = vector_layer.fields().indexFromName("risque_score")
    idx_max = vector_layer.fields().indexFromName("risque_max_pct")

    vector_layer.startEditing()
    for feat in vector_layer.getFeatures():
        best_tier = "Aucun risque"
        best_val = 0.0

        try:
            for field_name, kind in indicator_specs:
                idx = vector_layer.fields().indexFromName(field_name)
                if idx == -1:
                    continue
                val = feat.attribute(idx)
                try:
                    val = float(val) if val is not None else 0.0
                except (TypeError, ValueError):
                    val = 0.0

                tier = _weight_to_tier(val) if kind == "weight" else _percentage_to_tier(val, threshold)

                if _TIER_RANK[tier] > _TIER_RANK[best_tier]:
                    best_tier = tier
                best_val = max(best_val, val)
        except Exception:
            # Garde-fou : meme si une entite pose probleme (donnee
            # corrompue, attribut inattendu...), on ecrit tout de meme une
            # valeur par defaut plutot que de laisser la cellule vide --
            # une cellule 'risque_score' vide n'est jamais acceptable.
            best_tier = best_tier or "Aucun risque"

        # Ecriture inconditionnelle : quoi qu'il arrive ci-dessus, chaque
        # entite recoit une valeur (jamais NULL/vide).
        vector_layer.changeAttributeValue(feat.id(), idx_score, best_tier)
        vector_layer.changeAttributeValue(feat.id(), idx_max, round(best_val, 2))

    vector_layer.commitChanges()

    # Passe de verification finale : si, malgre tout, une entite s'est
    # retrouvee avec un risque_score NULL/vide (edition partielle,
    # provider capricieux...), on la corrige explicitement dans une
    # seconde passe d'edition, pour garantir qu'aucune ligne du resultat
    # n'affiche une cellule 'risque_score' vide.
    blanks = []
    for feat in vector_layer.getFeatures():
        val = feat.attribute(idx_score)
        if val is None or (isinstance(val, str) and val.strip() == ""):
            blanks.append(feat.id())
    if blanks:
        vector_layer.startEditing()
        for fid in blanks:
            vector_layer.changeAttributeValue(fid, idx_score, "Aucun risque")
            vector_layer.changeAttributeValue(fid, idx_max, 0.0)
        vector_layer.commitChanges()

    return "risque_score", "risque_max_pct"


def compute_single_layer_risk_score(vector_layer, field_name, kind, threshold, output_field_name):
    """Calcule le niveau de risque (Tres faible a Tres eleve) pour UNE
    SEULE couche de reference, a partir de son champ indicateur deja
    calcule (field_name), et l'ajoute comme champ texte distinct
    (output_field_name). Meme logique de conversion que compute_risk_score
    (kind='weight' ou 'percentage'), mais appliquee a un seul indicateur
    au lieu du maximum de tous -- pour que chaque couche de reference ait
    sa propre colonne de niveau, en plus du score global agrege.
    Retourne output_field_name."""
    if vector_layer.fields().indexFromName(output_field_name) == -1:
        vector_layer.dataProvider().addAttributes(
            [QgsField(output_field_name, FIELD_TYPE_STRING)]
        )
    vector_layer.updateFields()

    idx_out = vector_layer.fields().indexFromName(output_field_name)
    idx_in = vector_layer.fields().indexFromName(field_name)

    vector_layer.startEditing()
    for feat in vector_layer.getFeatures():
        val = feat.attribute(idx_in) if idx_in != -1 else None
        try:
            val = float(val) if val is not None else 0.0
        except (TypeError, ValueError):
            val = 0.0
        tier = _weight_to_tier(val) if kind == "weight" else _percentage_to_tier(val, threshold)
        vector_layer.changeAttributeValue(feat.id(), idx_out, tier)
    vector_layer.commitChanges()

    # Meme garde-fou que compute_risk_score : aucune cellule ne doit
    # rester vide.
    blanks = []
    for feat in vector_layer.getFeatures():
        val = feat.attribute(idx_out)
        if val is None or (isinstance(val, str) and val.strip() == ""):
            blanks.append(feat.id())
    if blanks:
        vector_layer.startEditing()
        for fid in blanks:
            vector_layer.changeAttributeValue(fid, idx_out, "Aucun risque")
        vector_layer.commitChanges()

    return output_field_name


def build_comment_field(
    vector_layer, comment_specs, field_name="commentaire", presence_threshold=0.5
):
    """Construit un champ texte expliquant les CAUSES du risque pour
    chaque parcelle (ex: 'Espace anciennement foret', 'Parcelle en Foret
    classee'). comment_specs est une liste de tuples
    (nom_du_champ_indicateur, texte_du_commentaire) : pour chaque
    parcelle, tous les commentaires dont l'indicateur associe depasse
    presence_threshold (%, par defaut 0.5 pour ignorer le bruit
    d'arrondi) sont concatenes avec ' ; '. Ajoute field_name (texte) a
    vector_layer et retourne son nom."""
    if vector_layer.fields().indexFromName(field_name) == -1:
        vector_layer.dataProvider().addAttributes([QgsField(field_name, FIELD_TYPE_STRING)])
        vector_layer.updateFields()

    idx_comment = vector_layer.fields().indexFromName(field_name)

    vector_layer.startEditing()
    for feat in vector_layer.getFeatures():
        parts = []
        for indicator_field, comment_text in comment_specs:
            if not comment_text:
                continue
            fidx = vector_layer.fields().indexFromName(indicator_field)
            if fidx == -1:
                continue
            val = feat.attribute(fidx)
            try:
                val = float(val) if val is not None else 0.0
            except (TypeError, ValueError):
                val = 0.0
            if val > presence_threshold:
                parts.append(comment_text)
        vector_layer.changeAttributeValue(feat.id(), idx_comment, " ; ".join(parts))
    vector_layer.commitChanges()
    return field_name


def remove_fields(vector_layer, field_names):
    """Supprime une liste de champs (utilise pour nettoyer les champs
    temporaires crees uniquement pour detecter la presence de classes
    individuelles servant a construire le commentaire, une fois celui-ci
    construit)."""
    field_names = [f for f in field_names if f]
    if not field_names:
        return
    indices = sorted(
        {vector_layer.fields().indexFromName(n) for n in field_names} - {-1},
        reverse=True,
    )
    if not indices:
        return
    vector_layer.startEditing()
    vector_layer.dataProvider().deleteAttributes(list(indices))
    vector_layer.updateFields()
    vector_layer.commitChanges()


def _hex_from_qcolor(qcolor):
    """Convertit un QColor en chaine hex 'RRGGBB' (sans '#'), format
    attendu par openpyxl pour les couleurs de remplissage."""
    return "%02X%02X%02X" % (qcolor.red(), qcolor.green(), qcolor.blue())


# Couleurs de risque en hexadecimal (memes couleurs que la symbologie
# cartographique RISK_LEVEL_COLORS), pour une coherence visuelle entre la
# carte QGIS et le rapport Excel.
RISK_LEVEL_HEX = {level: _hex_from_qcolor(c) for level, c in RISK_LEVEL_COLORS.items()}
RISK_LEVEL_TEXT_HEX = {
    "Aucun risque": "1A1A1A",
    "Très faible": "FFFFFF", "Faible": "1A1A1A", "Moyen": "1A1A1A",
    "Élevé": "FFFFFF", "Très élevé": "FFFFFF",
}


def export_excel_report(
    vector_layer,
    output_path,
    title,
    parcel_layer_name,
    total_parcels,
    risk_counts,
    threshold,
    reference_descriptions,
    analysis_datetime=None,
    at_risk_rows=None,
    logo_path=None,
    signature_path=None,
    signatory_name=None,
    signatory_date=None,
):
    """Genere un rapport Excel (.xlsx) sur plusieurs feuilles, avec mise en
    forme soignee (couleurs de risque, en-tetes colores, largeurs de
    colonnes ajustees) :
      - 'Resume' : logo, date/heure, statistiques, repartition du risque
        (tableau colore), methodologie ;
      - 'Parcelles a risque' : tableau des parcelles Moyen/Eleve/Tres eleve,
        triees par gravite, avec la cellule de niveau coloree ;
      - 'Resultat complet' : la table attributaire complete de la couche
        resultat, avec la colonne risque_score coloree par niveau.
    Utilise openpyxl (deja requis pour l'export Excel simple).
    Retourne True en cas de succes, ou (False, message) en cas d'echec
    (meme convention que export_layer, pour un affichage d'erreur clair)."""
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
        from openpyxl.drawing.image import Image as XLImage
    except ImportError:
        return (
            1,
            "Le module Python 'openpyxl' n'est pas installe dans l'environnement "
            "QGIS. Installe-le depuis l'invite OSGeo4W avec :\n"
            "python3 -m pip install openpyxl --user"
        )

    # QGIS represente les valeurs manquantes par son propre objet NULL
    # (import qgis.core.NULL), different du None de Python -- openpyxl ne
    # sait pas le convertir et leve "Cannot convert NULL to Excel" si on
    # le lui transmet tel quel. On le neutralise systematiquement avant
    # toute ecriture de cellule.
    try:
        from qgis.core import NULL as QGIS_NULL
    except Exception:
        QGIS_NULL = None

    def clean(val):
        """Convertit toute valeur QGIS (NULL, QDate/QDateTime, etc.) en une
        valeur que openpyxl sait ecrire sans erreur."""
        if val is None:
            return None
        try:
            if QGIS_NULL is not None and val == QGIS_NULL:
                return None
        except Exception:
            pass
        # Les types Qt (QDate, QDateTime, QVariant residuel...) sont
        # convertis en texte plutot que transmis tels quels.
        if not isinstance(val, (str, int, float, bool)):
            try:
                return str(val)
            except Exception:
                return None
        return val

    try:
        GREEN_DARK = "1B5E20"
        GREEN_LIGHT = "E8F5E9"
        GREY_LIGHT = "F4F4F4"
        BORDER_THIN = Border(*(Side(style="thin", color="CCCCCC"),) * 4)

        wb = openpyxl.Workbook()

        # ---------------------------------------------------------------
        # Feuille 1 : Resume
        # ---------------------------------------------------------------
        ws = wb.active
        ws.title = "Resume"
        ws.sheet_view.showGridLines = False
        ws.column_dimensions["A"].width = 32
        ws.column_dimensions["B"].width = 40

        row = 1
        if logo_path:
            try:
                img = XLImage(logo_path)
                # Redimensionnement proportionnel : on calcule le ratio a
                # partir des dimensions ORIGINALES de l'image (avant toute
                # modification), puis on l'applique a la fois a la hauteur
                # et a la largeur. L'ancien code ecrasait d'abord
                # img.height, puis calculait le ratio a partir de cette
                # valeur deja modifiee (img.height / img.height == 1), ce
                # qui laissait la largeur inchangee et deformait le logo
                # (etirement horizontal) en plus de le faire deborder sur
                # les colonnes suivantes.
                orig_w, orig_h = img.width, img.height
                max_h, max_w = 70, 220  # pixels ; max_w tient dans la colonne A (largeur 32)
                scale = min(max_h / orig_h, max_w / orig_w, 1.0)
                img.width = int(orig_w * scale)
                img.height = int(orig_h * scale)
                ws.add_image(img, "A1")
                # La ligne 1 est reservee au logo : sa hauteur (en points,
                # 1 px = 0.75 pt) doit suivre la hauteur reelle de l'image
                # inseree, avec une petite marge, pour eviter que le logo
                # ne chevauche le titre affiche juste en dessous.
                ws.row_dimensions[1].height = img.height * 0.75 + 8
                row = 2
            except Exception:
                pass

        ws.cell(row=row, column=1, value=title).font = Font(
            size=16, bold=True, color=GREEN_DARK
        )
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=2)
        row += 1

        info_rows = [
            ("Couche analysée", parcel_layer_name),
            ("Date et heure de l'analyse", analysis_datetime or ""),
            ("Nombre de parcelles / points analysés", total_parcels),
            ("Seuil de risque 'Élevé'", f"{threshold} %"),
        ]
        for label, value in info_rows:
            c1 = ws.cell(row=row, column=1, value=label)
            c1.font = Font(bold=True)
            ws.cell(row=row, column=2, value=value)
            row += 1

        row += 1
        header = ws.cell(row=row, column=1, value="Répartition du risque")
        header.font = Font(size=13, bold=True, color=GREEN_DARK)
        row += 1

        display_order = ["Très élevé", "Élevé", "Moyen", "Faible", "Très faible", "Aucun risque"]
        th1 = ws.cell(row=row, column=1, value="Niveau de risque")
        th2 = ws.cell(row=row, column=2, value="Nombre de parcelles")
        for th in (th1, th2):
            th.font = Font(bold=True, color="FFFFFF")
            th.fill = PatternFill("solid", fgColor=GREEN_DARK)
            th.border = BORDER_THIN
        row += 1
        for level in display_order:
            if level not in risk_counts:
                continue
            c1 = ws.cell(row=row, column=1, value=level)
            c2 = ws.cell(row=row, column=2, value=risk_counts.get(level, 0))
            fill = PatternFill("solid", fgColor=RISK_LEVEL_HEX.get(level, "FFFFFF"))
            text_color = RISK_LEVEL_TEXT_HEX.get(level, "000000")
            for c in (c1, c2):
                c.fill = fill
                c.font = Font(color=text_color, bold=True)
                c.border = BORDER_THIN
            row += 1

        row += 1
        header = ws.cell(row=row, column=1, value="Méthodologie -- couches de référence utilisées")
        header.font = Font(size=13, bold=True, color=GREEN_DARK)
        row += 1
        for desc in (reference_descriptions or []):
            ws.cell(row=row, column=1, value=f"• {desc}")
            ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=2)
            row += 1

        if signatory_name or signatory_date:
            row += 2
            sig_line = " - ".join(x for x in (signatory_name, signatory_date) if x)
            if signature_path:
                try:
                    sig_img = XLImage(signature_path)
                    sig_img.height = min(sig_img.height, 50)
                    ws.add_image(sig_img, f"A{row}")
                    row += 4
                except Exception:
                    pass
            c = ws.cell(row=row, column=1, value=sig_line)
            c.font = Font(italic=True)
            ws.alignment = Alignment(horizontal="right")

        # ---------------------------------------------------------------
        # Feuille 2 : Parcelles a risque
        # ---------------------------------------------------------------
        ws2 = wb.create_sheet("Parcelles a risque")
        ws2.sheet_view.showGridLines = False
        headers = ["Code parcelle", "Niveau de risque", "Score (%)"]
        for col, h in enumerate(headers, start=1):
            c = ws2.cell(row=1, column=col, value=h)
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor=GREEN_DARK)
            c.border = BORDER_THIN
        for r, (code, level, pct) in enumerate((at_risk_rows or []), start=2):
            c1 = ws2.cell(row=r, column=1, value=clean(code))
            c2 = ws2.cell(row=r, column=2, value=clean(level))
            c3 = ws2.cell(row=r, column=3, value=clean(round(pct, 1)))
            fill = PatternFill("solid", fgColor=RISK_LEVEL_HEX.get(level, "FFFFFF"))
            text_color = RISK_LEVEL_TEXT_HEX.get(level, "000000")
            c2.fill = fill
            c2.font = Font(color=text_color, bold=True)
            for c in (c1, c2, c3):
                c.border = BORDER_THIN
        ws2.column_dimensions["A"].width = 22
        ws2.column_dimensions["B"].width = 18
        ws2.column_dimensions["C"].width = 12
        ws2.freeze_panes = "A2"

        # ---------------------------------------------------------------
        # Feuille 3 : Resultat complet (table attributaire)
        # ---------------------------------------------------------------
        ws3 = wb.create_sheet("Resultat complet")
        ws3.sheet_view.showGridLines = False
        field_names = [f.name() for f in vector_layer.fields()]
        for col, name in enumerate(field_names, start=1):
            c = ws3.cell(row=1, column=col, value=name)
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor=GREEN_DARK)
            c.border = BORDER_THIN
        idx_score = (
            field_names.index("risque_score") + 1
            if "risque_score" in field_names else None
        )
        for r, feat in enumerate(vector_layer.getFeatures(), start=2):
            for col, name in enumerate(field_names, start=1):
                val = clean(feat[name])
                # Garde-fou d'affichage : une cellule risque_score ne doit
                # jamais rester vide, meme si la donnee source est NULL
                # pour une raison quelconque.
                if idx_score and col == idx_score and (val is None or str(val).strip() == ""):
                    val = "Aucun risque"
                c = ws3.cell(row=r, column=col, value=val)
                c.border = BORDER_THIN
                if idx_score and col == idx_score and val in RISK_LEVEL_HEX:
                    c.fill = PatternFill("solid", fgColor=RISK_LEVEL_HEX[val])
                    c.font = Font(color=RISK_LEVEL_TEXT_HEX.get(val, "000000"), bold=True)
                elif r % 2 == 0:
                    c.fill = PatternFill("solid", fgColor=GREY_LIGHT)
        for col in range(1, len(field_names) + 1):
            ws3.column_dimensions[get_column_letter(col)].width = 16
        ws3.freeze_panes = "A2"

        wb.save(output_path)
    except Exception as exc:
        return (1, f"Echec de la generation du rapport Excel : {exc}")

    return (0, "")
