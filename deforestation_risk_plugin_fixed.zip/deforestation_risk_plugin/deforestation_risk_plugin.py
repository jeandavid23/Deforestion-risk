# -*- coding: utf-8 -*-
"""
deforestation_risk_plugin.py
Classe principale : enregistre l'action dans le menu et la barre d'outils QGIS.
"""

import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon


class DeforestationRiskPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dialog = None
        self.action = None
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Analyse de risque de deforestation", self.iface.mainWindow())
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Deforestation Risk Analyzer", self.action)

    def unload(self):
        self.iface.removePluginMenu("&Deforestation Risk Analyzer", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        from .risk_dialog import RiskDialog
        if self.dialog is None:
            self.dialog = RiskDialog(self.iface, self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
