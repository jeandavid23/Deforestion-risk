# -*- coding: utf-8 -*-
"""
Deforestation Risk Analyzer
Point d'entree du plugin QGIS. QGIS appelle classFactory() au chargement.
"""


def classFactory(iface):
    from .deforestation_risk_plugin import DeforestationRiskPlugin
    return DeforestationRiskPlugin(iface)
