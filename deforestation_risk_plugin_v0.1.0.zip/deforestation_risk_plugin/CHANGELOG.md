# Changelog — Deforestation Risk Analyzer

All notable changes to this plugin follow [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) format.

---

## [0.1.0] — 2026-08-08 — Initial experimental release

### Added
- **Multi-layer analysis**: load any number of raster (GeoTIFF) and vector (Shapefile)
  reference layers alongside the official JRC GFC2020 WMS layer.
- **Hansen GFC auto-download**: automatic tile download (lossyear, treecover2000)
  covering the parcel extent, with local cache and multi-tile VRT merge.
- **ESA WorldCover 10m**: remote read via `/vsicurl/` (no full download, no API key)
  for 2020 and 2021 editions.
- **Raster classification UI**: automatic detection of pixel classes; per-class
  risk level (5 levels: Très faible → Très élevé) and cause comment assignment;
  Excel paste support (Ctrl+V / right-click) for bulk class labelling.
- **Vector class filter**: per-field class selector with checkboxes; optional
  cause comment per checked classes.
- **Risk score engine**:
  - For classified rasters: highest-level class logic (no diluted average).
  - For unclassified rasters / shapefiles: % overlap vs configurable threshold.
  - Composite `risque_score` (worst level across all active layers).
  - Per-layer risk column (`<prefix>risque`) for traceability.
  - Per-layer cause comment column (`<prefix>comment`).
- **Excel report** (openpyxl): 3 sheets — summary with risk distribution table,
  at-risk parcels sorted by severity, full attribute table with colour-coded
  risk cells. Optional logo and signature image.
- **Performance**: raster clipped to parcel extent before any zonal statistics;
  raster de-duplication to avoid re-clipping across risk levels.
- **Cancel button**: interrupts in-progress analysis (clip / reclassify / zonal
  statistics all honour `QgsProcessingFeedback`).
- **Qt5 / Qt6 compatibility**: all enum paths resolved at load time via
  `_compat_enum()` helpers, tested on QGIS 3.16 → 3.40.
- **Security**: URL allow-list in Hansen downloader (only
  `storage.googleapis.com`); all non-blocking exceptions logged via
  `QgsMessageLog` (no silent `pass`).
- **Config cache**: class labels, risk levels, and comments are remembered per
  layer across re-opens of the classification dialog.
